#include "funicularScene.h"
#include "SecondTollgate_2.h"
#include "File.h"
#include "downScene.h"
#include <fstream>

Scene * funicularScene::createScene()
{
	auto scene = Scene::create();
	auto layer = funicularScene::create();
	scene->addChild(layer);
	return scene;
}

bool funicularScene::init()
{
		if (!Layer::init())
		{
			return false;
		}
		//����ͼƬ
		auto background = Sprite::create("secondScene.png");
		background->setPosition(Vec2(800, 320));
		addChild(background);

		//�³�����
		auto funicularAndMan = Sprite::create("funicularAndMan.png");
		funicularAndMan->setPosition(Vec2(770, 284));
		addChild(funicularAndMan);
		/////////////////////////////////////��ɽ·��////////////////////////////////////////
		MoveBy* moveBy5 = MoveBy::create(2, ccp(220, 0));
		Action* actions1 = Sequence::create(moveBy5, NULL);
		background->runAction(actions1);

			// �����ƶ��������� 
			MoveBy* moveBy1 = MoveBy::create(2, ccp(40, 75));
			MoveBy* moveBy2 = MoveBy::create(2, ccp(-250, 50));
			MoveBy* moveBy3 = MoveBy::create(2, ccp(-290, 45));
			MoveBy* moveBy4 = MoveBy::create(2, ccp(-255, 130));
			CCActionInterval * easeSineOut = CCEaseSineIn::create(moveBy1);
			CCActionInterval * easeSineIn = CCEaseSineOut::create(moveBy4);
		// ������϶������󣬽����ж��������� 
		Action* actions = Sequence::create(moveBy1, moveBy2, moveBy3, moveBy4, NULL);

		funicularAndMan->runAction(actions);

		this->scheduleUpdate();
		//������ʱ�����ж��Ƿ�ʱ���Ե�������
		auto timecount = CallbackTimeCounter::create();
		this->addChild(timecount);
		timecount->start(8.0f, [=]() //ʱ��Ϊ�˲��Է�����ʱд��5�룬ʵ��ӦΪ120��
		{
			Size size = Director::getInstance()->getVisibleSize();
			LabelTTF* tip = LabelTTF::create("Shangyu is not at the top of the hill.\n ", "UWJACK8", 40);
			tip->setPosition(size.width / 2, size.height / 2);
			this->addChild(tip);
		
			MenuItemImage* back = MenuItemImage::create("returnPaybox.png", "returnPaybox.png", CC_CALLBACK_1(funicularScene::down, this));
			auto menu_1 = Menu::create(back, NULL);
			menu_1->setPosition(size.width / 2, size.height / 2-300);
			this->addChild(menu_1);

			//�����ʱ����Զ��
			File file(getTheName(), getPassword());
			if (file.checkTelescope())
			{
				file.getSecondSceneTip(1);
				LabelTTF* backto = LabelTTF::create("By using telescope,\nyou find murder is leaving.\nReturn to find ID of murder.\n ", "UWJACK8", 40);
				backto->setPosition(size.width / 2, size.height / 2-200);
				this->addChild(backto);
			}
		});
		
		return true;
	}

void funicularScene::update(float delta)
{
	this->removeChild(funicularlabeltime);
	std::stringstream ss;
	std::string val;
	ss << int(leftTime.getTime() / 60);
	ss >> val;
	funicularlabeltime = LabelTTF::create(val, "Arial", 60);
	funicularlabeltime->setPosition(Vec2(600, 600));
	this->addChild(funicularlabeltime);

	if (leftTime.setTime(1.0f))
		return;
	else
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SecondTollgate_2::createScene()));
	}

}

void funicularScene::down(Ref * pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, downScene::createScene()));
}

string  funicularScene::getTheName()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	tempfile >> temp;
	tempfile.close();

	return temp;
}

string  funicularScene::getPassword()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp1;
	string temp;
	tempfile >> temp1;
	tempfile >> temp;
	tempfile.close();
	return temp;
}
