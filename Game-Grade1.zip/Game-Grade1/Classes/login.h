#ifndef __login_h__
#define __login_h__
#include<iostream>
#include <string>
#include"Calculagraph.h"
#include "cocos2d.h"
#include "TimeCounter.h"
#include "CallbackTimeCounter.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"file.h"

using namespace ui;
using namespace cocos2d;
using namespace std;

class Login :public cocos2d::Layer, public cocos2d::TextFieldDelegate
{
public:
	virtual bool init();
	void OkButton();
	static  cocos2d::Scene* createScene();
	CREATE_FUNC(Login);

private:
	Size m_size;
	EditBox * editBox;
	Size WinSize;
	string name;
	string password;
};
#endif
