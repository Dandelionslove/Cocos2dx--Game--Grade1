#pragma once
#ifndef _SecondTollgate_1_H
#define _SecondTollgate_1_H

#include"cocos2d.h"

using namespace cocos2d;

class SecondTollgate_1 :public Layer
{
public:
	SecondTollgate_1():isRing(false) {}
	static Scene* createScene();
	virtual bool init();
	void phoneRing(Ref* pSender);
	void next_scene(Ref* pSender);

	CREATE_FUNC(SecondTollgate_1);
protected:
	Menu* menu;
private:
	bool isRing;
};
#endif
