
#ifndef __THREE_SCENE33_H__
#define __THREE_SCENE33_H__
#include<iostream>
#include "cocos2d.h"
using namespace cocos2d;

class SCENE33 :public cocos2d::Layer {
public:
	virtual bool init();
	static  cocos2d::Scene* scene();
	CREATE_FUNC(SCENE33);
private:
	Sprite* account;
};
#endif
