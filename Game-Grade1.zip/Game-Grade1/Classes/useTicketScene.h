#ifndef __useTicketScene_H__
#define __useTicketScene_H__
#include"cocos2d.h"
#include<map>

#include"CallbackTimeCounter.h"
#include "Calculagraph.h"
using namespace cocos2d;
USING_NS_CC;
using namespace std;

class useTicketScene :public Layer
{
public:
	static Scene* createScene();
	virtual bool init();
	string getTheName();
	string getPassword();

	void useTicket(Ref*pSender);
	void returnUseTicketScene(Ref* pSender);
	void okUseTicket(Ref * pSender);
	void nextScene(Ref* pSender);
	void toSecondScene(Ref * pSender);
	void update(float delta)override;
	bool isKeyPressed(EventKeyboard::KeyCode keycode);
	void keyPressedDuration(EventKeyboard::KeyCode code);

	CREATE_FUNC(useTicketScene);
protected:
	Menu* menu;
	map<EventKeyboard::KeyCode, bool>keys;
	CCProgressTimer* progressTimer;
	CallbackTimeCounter* timecount;
	Calculagraph leftTime;
	Sprite* man;
	Calculagraph usetime;
	LabelTTF*  uselabeltime;
};

#endif // !__useTicketScene_H__
