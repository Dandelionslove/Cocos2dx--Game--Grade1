#include"MenuScene.h"
#include"SimpleAudioEngine.h"
#include"FirstTollgate_1.h"
#include "Calculagraph.h"
#include"Requirement.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "file.h"
#include "scene31.h"
#include <fstream>
#include "SecondTollgate_1.h"
#include"scenefinal2.h"
USING_NS_CC;
using namespace CocosDenshion;

Scene* MenuScene::createScene()
{
	auto scene = Scene::create();
	auto layer = MenuScene::create();
	scene->addChild(layer);
	return scene;
}

bool MenuScene::init()
{
	if (!Layer::init())
	{
		return false;
	}
	Sprite* background = Sprite::create("menuBG.png");
	background->setAnchorPoint(Vec2(1.0f, 1.0f));
	background->setPosition(Vec2(1.0f, 1.0f));
	background->setScaleX(960 / 400);
	background->setScaleY(640 / 566);
	this->addChild(background);
	SimpleAudioEngine::getInstance()->playBackgroundMusic("Lightening.mp3", true);

	auto startItem = MenuItemImage::create(
	"start.png",
		"start.png",
		CC_CALLBACK_1(MenuScene::to_firsttollgate,this));
	auto tollgateItem = MenuItemImage::create(
	"lastTollgate.png",
		"lastTollgate.png",
		CC_CALLBACK_1(MenuScene::to_tollgates,this));
	auto requirementItem = MenuItemImage::create(
		"introduce.png",
		"introduce.png",
		CC_CALLBACK_1(MenuScene::to_requirement, this));
	startItem->setScale(0.5f);
	tollgateItem->setScale(0.5f);
	requirementItem->setScale(0.5f);
	auto menu = Menu::create(startItem, requirementItem, tollgateItem, NULL);
	menu->setAnchorPoint(Vec2(0, 0));
	menu->setPosition(Vec2(470, 300));
	menu->alignItemsVerticallyWithPadding(10);
	this->addChild(menu);
	
	return true;
}

void MenuScene::to_firsttollgate(Ref* pSender)
{
	File file(getTheName(), getPassword());
	file.clearData();
	Calculagraph time;
	time.setTime(-7200+time.getTime());
	Director::getInstance()->replaceScene(FirstTollgate_1::createScene());
	SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
}

void MenuScene::to_tollgates(Ref* pSender)
{
	File file(getTheName(), getPassword());
	if (!(file.isFirstSceneSuccess()))
	{
		Director::getInstance()->pushScene(SCENEF2::scene());
		SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
	}

	if (file.isFirstSceneSuccess() && !(file.isSecondSceneSuccess()))
	{
		Director::getInstance()->pushScene(SecondTollgate_1::createScene());
		SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
	}
	if (file.isFirstSceneSuccess() && file.isSecondSceneSuccess())
	{
		Director::getInstance()->pushScene(SCENE31::createScene());
		SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
	}

}

string MenuScene::getTheName()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	tempfile >> temp;
	tempfile.close();

	return temp;
}

string MenuScene::getPassword()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp1;
	string temp;
	tempfile >> temp1;
	tempfile >> temp;
	tempfile.close();
	return temp;
}

void MenuScene::to_requirement(Ref* pSender)
{
	Director::getInstance()->pushScene(Requirement::createScene());
	SimpleAudioEngine::getInstance()->pauseBackgroundMusic();

}


