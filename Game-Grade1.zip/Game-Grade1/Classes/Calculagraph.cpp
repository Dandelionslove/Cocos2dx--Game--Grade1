#include "Calculagraph.h"
#include <string>
#include <cstdlib>
#include <fstream>
#include"cocos2d.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocostudio;
using namespace std;


Calculagraph::Calculagraph()
{
	ifstream rtimefile;
	rtimefile.open("time.txt", ios::in);
	if (!(rtimefile.is_open()))
	{
		ofstream wtimefile;
		wtimefile.open("time.txt");
		wtimefile << "7200" << endl;
		wtimefile.close();
	}
	rtimefile.close();

}

Calculagraph::~Calculagraph()
{
}

//����Ϊʱ��ļ���������λ����
bool Calculagraph::setTime(int time)
{
		std::stringstream ss;
		std::string val;
		ss << (this->getTime() - time);
		ss >> val;
		int len =  4 - val.length();
		for (int i = 0; i <len; i++)
		{
			val = "0" + val;
		}
		if (val == "0000")
			return 0;
		fstream file;
		file.open("time.txt", ios_base::in | ios_base::out | ios_base::binary);
		file.seekg(0);
		if (!file.is_open())
		{
			log("could not be opened\n");
			exit(EXIT_FAILURE);
		}
		file << val;
		return 1;
	}

int Calculagraph::getTime()
{
	ifstream file;
	file.open("time.txt", ios::in);
	if (!file)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	int num;
	file >> num;
	file.close();
	return num;
}

bool Calculagraph::deletetimeFile()
{
	return 	remove("time.txt");

}

bool Calculagraph::init()
{

	if (!Layer::init())
	{
		return false;
	}

}
