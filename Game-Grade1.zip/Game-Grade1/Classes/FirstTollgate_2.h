#pragma once
#ifndef FirstTollgate_2_H_
#define FirstTollgate_2_H_

#include"cocos2d.h"
#include"TimeCounter.h"
#include"CallbackTimeCounter.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

using namespace cocos2d;

class FirstTollgate_2 :public Layer
{
public:
	CREATE_FUNC(FirstTollgate_2);

	static Scene* createScene();
	virtual bool init();
	void go_next(Ref* pSender);
protected:
	Size size;
	CallbackTimeCounter* func_1;
	CallbackTimeCounter* func_2;

	Sprite *man;
};
#endif
