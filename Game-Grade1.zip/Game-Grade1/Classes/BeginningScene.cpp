#include "BeginningScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"BackGround.h"

USING_NS_CC;

using namespace cocostudio::timeline;

Scene* BeginningScene::createScene()
{
    auto scene = Scene::create();
    auto layer = BeginningScene::create();
    scene->addChild(layer);
    return scene;
}

bool BeginningScene::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
 
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    
    auto label =CCLabelTTF::create("We need you to change a story", "UWJACK8", 40);
    label->setPosition(Vec2(origin.x + visibleSize.width/2,
                            origin.y + visibleSize.height - label->getContentSize().height));
    this->addChild(label, 1);
    auto sprite = Sprite::create("beginBG.png");
    sprite->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
    this->addChild(sprite, 0);
    
    //��ʱ�¼�
	callback = CallbackTimeCounter::create();
	this->addChild(callback);
	callback->start(2.0f, [=]()
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.2f, BackGround::createScene()));
	});
    
    return true;
}
