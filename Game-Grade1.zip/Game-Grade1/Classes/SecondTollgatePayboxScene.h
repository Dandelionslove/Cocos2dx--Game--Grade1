#ifndef __SecondTollgatePayboxScene_H__
#define __SecondTollgatePayboxScene_H__

#include "PayboxScene.h"
using namespace cocos2d;
USING_NS_CC;
using namespace std;

class  SecondTollgatePayboxScene :public payboxScene
{
public:

	virtual bool init();
	void returnPaybox(Ref* pSender);
	void okBuyTicket(Ref * pSender);
	void toSecondScene(Ref * pSender);
	void update(float delta)override;
	bool isKeyPressed(EventKeyboard::KeyCode keycode);
	void keyPressedDuration(EventKeyboard::KeyCode code);


	CREATE_FUNC(payboxScene);
protected:
	Menu* menu;
	map<EventKeyboard::KeyCode, bool>keys;
	CCProgressTimer* progressTimer;
	Calculagraph leftTime;
	Sprite* man;
	Calculagraph paytime;
	LabelTTF*  paylabeltime;
};
#endif
