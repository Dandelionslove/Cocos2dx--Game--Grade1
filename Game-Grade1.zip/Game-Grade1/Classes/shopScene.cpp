#include"shopScene.h"
#include "File.h"
#include"SecondTollgate_2.h"
#include"SimpleAudioEngine.h"
#include<cstdlib>
#include <fstream>

USING_NS_CC;
using namespace CocosDenshion;
using namespace std;

Scene*shopScene::createScene()
{
	auto scene = Scene::create();
	auto layer = shopScene::create();
	scene->addChild(layer);
	return scene;
}

bool shopScene::init()
{
	if (!Layer::init())
	{
		return false;
	}
	//����ͼƬ
	auto scene = Sprite::create("shopBG.png");
	Size size = Director::getInstance()->getVisibleSize();
	scene->setPosition(Vec2(size.width / 2, size.height / 2));
	scene->setScaleX(960 / 648);
	scene->setScaleY(640 / 432);
	this->addChild(scene, 0);

	//��Զ��
	auto  telescope = MenuItemImage::create("telescope.png", "telescope.png", CC_CALLBACK_1(shopScene::buyTelescope, this));
	menu = Menu::create(telescope, NULL);
	menu->setPosition(Vec2(300, 400));
	this->addChild(menu, 1);

	//��ɡ
	auto  umbrella = MenuItemImage::create("umbrella.png", "umbrella.png", CC_CALLBACK_1(shopScene::buyUmbrella, this));
	auto menu_7 = Menu::create(umbrella, NULL);
	menu_7->setPosition(Vec2(660, 400));
	this->addChild(menu_7, 1);

	this->scheduleUpdate();


	//���صڶ��ؿ�������
	auto returnPaybox = MenuItemImage::create(
		"returnPaybox.png",
		"returnPaybox.png",
		CC_CALLBACK_1(shopScene::returnSecondScene, this));
	auto menu_6 = Menu::create(returnPaybox, NULL);
	menu_6->setPosition(Vec2(100, 120));
	this->addChild(menu_6);

	//����һ��������ť
	pack = MenuItemImage::create("pack_button.png", "pack_button.png", CC_CALLBACK_1(shopScene::show_pack, this));
	auto menu_3 = Menu::create(pack, NULL);
	this->addChild(menu_3, 5);
	menu_3->setPosition(50, 170);
	return true;
}

void shopScene::buyTelescope(Ref * pSender)
{
	//�Ի���//////////////////////ѯ���Ƿ�����Զ��/////////////////////////////
	auto hello = Sprite::create("maiwangyuanjing.png");
	hello->setPosition(Vec2(400, 500));
	addChild(hello);

	//ȷ�Ϲ���
	auto ok = MenuItemImage::create(
		"ok.png",
		"ok.png",
		CC_CALLBACK_1(shopScene::okBuyTelescope, this));
	auto menu_5 = Menu::create(ok, NULL);
	menu_5->setPosition(Vec2(750, 120));
	this->addChild(menu_5);

	//����shopScene
	auto returnPaybox = MenuItemImage::create(
		"returnPaybox.png",
		"returnPaybox.png",
		CC_CALLBACK_1(shopScene::returnshopScene, this));
	auto menu_8 = Menu::create(returnPaybox, NULL);
	menu_8->setPosition(Vec2(500, 120));
	this->addChild(menu_8);


}

void shopScene::buyUmbrella(Ref * pSender)
{
	//�Ի���//////////////////////ѯ���Ƿ�����ɡ/////////////////////////////
	auto hello = Sprite::create("buyumbrella.png");
	hello->setPosition(Vec2(400, 500));
	addChild(hello);

	//ȷ�Ϲ���
	auto ok = MenuItemImage::create(
		"ok.png",
		"ok.png",
		CC_CALLBACK_1(shopScene::okBuyUmbrella, this));
	auto menu_5 = Menu::create(ok, NULL);
	menu_5->setPosition(Vec2(750, 120));
	this->addChild(menu_5);

	//����shopScene
	auto returnPaybox = MenuItemImage::create(
		"returnPaybox.png",
		"returnPaybox.png",
		CC_CALLBACK_1(shopScene::returnshopScene, this));
	auto menu_8 = Menu::create(returnPaybox, NULL);
	menu_8->setPosition(Vec2(300, 120));
	this->addChild(menu_8);

}

void shopScene::returnshopScene(Ref * pSender)
{
	Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f, shopScene::createScene()));
}

string shopScene::getTheName()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	tempfile >> temp;
	tempfile.close();

	return temp;
}

string shopScene::getPassword()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp1;
	string temp;
	tempfile >> temp1;
	tempfile >> temp;
	tempfile.close();
	return temp;
}

void shopScene::okBuyTelescope(Ref * pSender)
{
	File file(getTheName(), getPassword());

	//��Զ���ļ۸�
	int num = 2000;
	auto timecount = CallbackTimeCounter::create();
	this->addChild(timecount);
	if (file.checkTelescope())
	{
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("You had got the telescope.\n ", "UWJACK8", 40);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);
		timecount->start(3.0f, [=]()
		{
			this->removeChild(tip);
			Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f, shopScene::createScene()));
		});

	}

	if (!(file.checkTelescope())&&file.getMoney() < num)
	{
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("You do not have enough\nmoney to but it.\n ", "UWJACK8", 40);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);

		timecount->start(3.0f, [=]()
		{
			this->removeChild(tip);
			Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f, shopScene::createScene()));
		});

	}

	if (!(file.checkTelescope()) && file.getMoney() > num)
	{
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("You get the telescope.\n ", "UWJACK8", 40);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);

		file.moneyDecrease(num);
		file.buyTelescope();
		timecount->start(3.0f, [=]()
		{
			this->removeChild(tip);
			Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f, shopScene::createScene()));
		});

	}
}

void shopScene::okBuyUmbrella(Ref * pSender)
{
	File file(getTheName(), getPassword());
	//��ɡ�ļ۸�
	int num = 1500;
	auto timecount = CallbackTimeCounter::create();
	this->addChild(timecount);
	if (file.checkUmbrella())
	{
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("You had got umbrella.\n ", "UWJACK8", 40);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);
		timecount->start(3.0f, [=]()
		{
			this->removeChild(tip);
			Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f, shopScene::createScene()));
		});

	}
	if (!(file.checkUmbrella())&&file.getMoney() < num)
	{
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("You do not have enough\nmoney to but it.\n ", "UWJACK8", 40);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);
		timecount->start(3.0f, [=]()
		{
			this->removeChild(tip);
			Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f, shopScene::createScene()));
		});

	}
	if (!(file.checkUmbrella()) && file.getMoney() > num)
	{
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("You get the umbrella.\n ", "UWJACK8", 40);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);

		file.moneyDecrease(num);
		file.buyUmbrella();

		timecount->start(3.0f, [=]()
		{
			this->removeChild(tip);
			Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f, shopScene::createScene()));
		});

	}

}

void shopScene::returnSecondScene(Ref * pSender)
{
	Director::getInstance()->popScene();
}

void shopScene::update(float delta)
{
	this->removeChild(shoplabeltime);
	std::stringstream ss;
	std::string val;
	ss << int(leftTime.getTime() / 60);
	ss >> val;
	shoplabeltime = LabelTTF::create(val, "UWJACK8", 60);
	shoplabeltime->setPosition(Vec2(600, 600));
	this->addChild(shoplabeltime);

	if (leftTime.setTime(1.0f))
		return;
	else
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SecondTollgate_2::createScene()));
	}

}

void shopScene::show_pack(Ref * pSender)
{
	Size size = Director::getInstance()->getVisibleSize();
	File file;
	backpack = Sprite::create("backpack.png");
	this->addChild(backpack);
	backpack->setPosition(size.width / 2, size.height / 2);
	auto pack_menu = Menu::create();
	backpack->addChild(pack_menu);
	pack_menu->setPosition(size.width / 2, size.height / 2);
	//�����ֵı���////////////////��˫�����ȴ��������ж�����ͼƬ��������ע��������ʹ�ð�ť����������Ϊ0����ʹ�ð�ť����////////////////////////////
	//////////////////////////////////��˫�����Ժ��ÿһ���ؿ������ϱ���////////////////////////////////////////////////
	////��˫��������֤
	//auto IDcard = ::create("IDcard2.png");
	//backpack->addChild(IDcard, 1);
	//IDcard->setPosition(150, 350);
	////��˫����Ǯ��
	//Value _money = Value(file.getMoney());
	//Value v = Value("Money Number: ");
	//string num = v.asString() + _money.asString();
	//auto money_num = CCLabelTTF::create(num, "Arial", 20);
	//backpack->addChild(money_num, 10);
	//money_num->setPosition(150, 300);
	//money_num->setColor(Color3B(0, 0, 0));//��˫�������õ�������ɫ���ɸ�

	//											//��˫��������������������
	//auto things_name = Sprite::create("things_name.png");
	//auto number = Sprite::create("number.png");
	//backpack->addChild(things_name);
	//backpack->addChild(number);
	//things_name->setPosition(150, 400);
	//number->setPosition(450, 400);

	////��˫����Ʊ
	//auto ticket = Sprite::create("ticket.png");
	//backpack->addChild(ticket, 1);
	//ticket->setPosition(150, 250);
	//Value num_1 = Value(file.checkTicket());
	//auto ticket_num = CCLabelTTF::create(num_1.asString(), "Arial", 20);
	//ticket->addChild(ticket_num);
	//ticket_num->setPosition(400, 250);
	//ticket_num->setColor(Color3B(0, 0, 0));
	////��˫�����ֻ�
	//auto phone = Sprite::create("phone.png");
	//backpack->addChild(phone, 1);
	//phone->setPosition(150, 180);
	//phone->setScale(0.3f);
	//auto phone_num = CCLabelTTF::create("1", "Arial", 20);
	//phone->addChild(phone_num);
	//phone_num->setPosition(500, 175);
	//phone_num->setScale(5);
	//phone_num->setColor(Color3B(0, 0, 0));
	//// ��˫������ֽ
	//auto newspaper = Sprite::create("newspaper.png");
	//backpack->addChild(newspaper);
	//newspaper->setPosition(150, 140);
	//Value num_2 = Value(file.checkNewspaper());
	//auto newspaper_num = CCLabelTTF::create(num_2.asString(), "Arial", 20);
	//newspaper->addChild(newspaper_num);
	//newspaper_num->setColor(Color3B(0, 0, 0));
	//newspaper_num->setPosition(420, 140);
	////��˫������Զ��
	//auto telescope = Sprite::create("telescope.png");
	//backpack->addChild(telescope);
	//telescope->setPosition(150, 100);
	//Value num_3 = Value(file.checkTelescope());
	//auto telescope_num = CCLabelTTF::create(num_3.asString(), "Arial", 20);
	//telescope->addChild(telescope_num);
	//telescope_num->setColor(Color3B(0, 0, 0));
	//telescope_num->setPosition(450, 100);
	////��˫������ɡ
	//auto umbrella = Sprite::create("umbrella3.png");
	//backpack->addChild(umbrella);
	//umbrella->setPosition(130, 60);
	//Value num_4 = Value(file.checkUmbrella());
	//auto umbrella_num = CCLabelTTF::create(num_3.asString(), "Arial", 20);
	//umbrella->addChild(umbrella_num);
	//umbrella_num->setColor(Color3B(0, 0, 0));
	//umbrella_num->setPosition(130, 60);

	//��������
	Value de = Value("\n");
	Value d_1 = Value("IDcard: Father ");
	Value d_2 = Value("Life Number: "); Value v_2 = Value(file.checkHeart());
	Value d_3 = Value("Money: "); Value v_3 = Value(file.getMoney());
	Value d_4 = Value("Telescope: "); Value v_4 = Value(file.checkTelescope());
	Value d_5 = Value("Ticket: "); Value v_5 = Value(file.checkTicket());
	Value d_6 = Value("Umbrella: "); Value v_6 = Value(file.checkUmbrella());
	Value d_7 = Value("Newspaper: "); Value v_7 = Value(file.checkNewspaper());
	string  pack_content = d_1.asString() + de.asString() + d_2.asString() + v_2.asString() + de.asString() + d_3.asString() + v_3.asString() + de.asString() + d_4.asString() + v_4.asString() + de.asString() + d_5.asString() + v_5.asString() + de.asString() + d_6.asString() + v_6.asString() + de.asString() + d_7.asString() + v_7.asString() + de.asString();
	auto _pack_content = CCLabelTTF::create(pack_content, "UWJACK8", 40);
	backpack->addChild(_pack_content, 5);
	_pack_content->setPosition(350, 200);
	/*Value life= Value(file.checkHeart());
	Value d = Value("Life Number: ");

	string  life_num = d.asString() + life.asString();
	auto _life_num = CCLabelTTF::create(life_num, "Arial", 20);
	backpack->addChild(_life_num,15);
	_life_num->setColor(Color3B(0, 0, 0));
	_life_num->setPosition(120, 200);*/

	////��˫����������Ϸ����İ�ť
	auto back_scene = MenuItemImage::create("back_scene.png", "back_scene.png", CC_CALLBACK_1(shopScene::hide_pack, this));
	auto back_scene_button = Menu::create(back_scene, NULL);
	backpack->addChild(back_scene_button);
	back_scene_button->setPosition(400, 30);


}

void shopScene::hide_pack(Ref * pSender)
{
	this->removeChild(backpack);
}

