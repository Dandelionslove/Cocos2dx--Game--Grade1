#include"scenefinal2.h"
#include"BeginningScene.h"
#include<iostream>
#include "CallbackTimeCounter.h"
#include "cocostudio/CocoStudio.h"
#include "file.h"
#include "ui/CocosGUI.h"
#include <fstream>
USING_NS_CC;
using namespace cocostudio::timeline;
using namespace CocosDenshion;

Scene*SCENEF2::scene()
{
	Scene*scene = Scene::create();
	SCENEF2*layer = SCENEF2::create();
	scene->addChild(layer);
	return scene;
}
bool SCENEF2::init()
{
	if (!Layer::init())
	{
		return false;
	}
	Size size = Director::sharedDirector()->getWinSize();
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Point origin = Director::getInstance()->getVisibleOrigin();

	float width = size.width;
	float height = size.height;
	CCSprite*bg3 = CCSprite::create("menuBG2.png");
	bg3->setPosition(ccp(size.width / 2, size.height / 2));
	float spx = bg3->getTextureRect().getMaxX();
	float spy = bg3->getTextureRect().getMaxY();
	bg3->setScaleX(width / spx);
	bg3->setScaleY(height / spy);
	this->addChild(bg3);
	SimpleAudioEngine::sharedEngine()->playBackgroundMusic("truevoice.mp3", false);

	auto words_1 = CCLabelTTF::create("Now you are listening the real voice of the murderer", "UWJACK8", 30);
	words_1->setColor(Color3B(255, 255, 255));
	this->addChild(words_1, 9);
	words_1->setPosition(size.width/2, 450);
	auto move = MoveTo::create(7.0f, Point(size.width / 2, 800));
	words_1->runAction(move);

	//������ʱ�� 
	CallbackTimeCounter* cbTimeCounter = CallbackTimeCounter::create();
	this->addChild(cbTimeCounter);

	//����Ԥ���л�ʱ��
	cbTimeCounter->start(68.0f, [&]() {
		float width = size.width;
		float height = size.height;
		Sprite*bg2 = Sprite::create("beginBG.png");
		bg2->setPosition(ccp(size.width / 2, size.height / 2));
		float spx = bg2->getTextureRect().getMaxX();
		float spy = bg2->getTextureRect().getMaxY();
		bg2->setScaleX(width / spx);
		bg2->setScaleY(height / spy);
		this->addChild(bg2);

		
		auto button1 = MenuItemImage::create(
			"tryAgain.png",
			"tryAgain.png",
			CC_CALLBACK_1(SCENEF2::Try_again, this));
		button1->setPosition(size.width/2, 100);
		auto button2 = MenuItemImage::create(
			"over.png",
			"over.png",
			CC_CALLBACK_1(SCENEF2::cancelMenuItemCallback, this));
		button2->setPosition(size.width / 2, 50);
		Menu*menu = Menu::create(button1, button2, NULL);
		this->addChild(menu);
		menu->alignItemsVerticallyWithPadding(10);
	});
	return true;
}
void SCENEF2::Try_again(cocos2d::Ref* pSender)
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string name;
	string password;
	tempfile >> name;
	tempfile >> password;
	tempfile.close();

	File file(name,password);
	file.clearData();
	Director::getInstance()->replaceScene(TransitionCrossFade::create(1.0f, BeginningScene::createScene()));
}
void SCENEF2::cancelMenuItemCallback(Ref* pSender)
{
	removeFromParentAndCleanup(true);
}
void SCENEF2::rollText(float)
{
	text->setPositionY(text->getPositionY() + 0.5);
}

