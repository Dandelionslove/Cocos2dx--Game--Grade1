#include"useTicketScene.h"
#include"SecondTollgate_2.h"
#include "funicularScene.h"
#include "MenuScene.h"
#include "TimeCounter.h"
#include "Calculagraph.h"
#include "CallbackTimeCounter.h"
#include"scene31.h"
#include <fstream>
#include"SimpleAudioEngine.h"
#include "file.h"
USING_NS_CC;
using namespace CocosDenshion;
using namespace std;

Scene* useTicketScene::createScene()
{
	auto scene = Scene::create();
	auto layer = useTicketScene::create();
	scene->addChild(layer);
	return scene;
}

bool useTicketScene::init()
{
	if (!Layer::init())
	{
		return false;
	}
	//����ͼƬ
	auto scene = Sprite::create("scene_1.jpg");
	Size size = Director::getInstance()->getVisibleSize();
	scene->setPosition(Vec2(size.width / 2, size.height / 2));
	scene->setScaleX(960 / 648);
	scene->setScaleY(640 / 432);
	this->addChild(scene, 0);

	//������Ա
	auto  personnel = MenuItemImage::create("worker.png", "worker.png", CC_CALLBACK_1(useTicketScene::useTicket, this));
	menu = Menu::create(personnel, NULL);
	menu->setPosition(Vec2(500, 100));
	this->addChild(menu);

	this->scheduleUpdate();
	//���صڶ��ؿ�������
	auto returnPaybox = MenuItemImage::create(
		"returnPaybox.png",
		"returnPaybox.png",
		CC_CALLBACK_1(useTicketScene::toSecondScene, this));
	auto menu_6 = Menu::create(returnPaybox, NULL);
	menu_6->setPosition(Vec2(100, 120));
	this->addChild(menu_6);


	return true;
}

string useTicketScene::getTheName()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	tempfile >> temp;
	tempfile.close();

	return temp;
}

string useTicketScene::getPassword()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp1;
	string temp;
	tempfile >> temp1;
	tempfile >> temp;
	tempfile.close();
	return temp;
}

void useTicketScene::useTicket(Ref * pSender)
{
	File file(getTheName(), getPassword());
	if (file.getSecondSceneTip())
	{
		//�ɹ�������ͼ/////////////����ID��Ϣ///////////////////
		auto scene = Sprite::create("ID.png");
		Size size = Director::getInstance()->getVisibleSize();
		scene->setPosition(Vec2(size.width / 2, size.height / 2));
		scene->setScaleX(960 / 648);
		scene->setScaleY(640 / 432);
		this->addChild(scene, 0);

		file.secondSceneSuccess();

		auto  next = MenuItemImage::create("next.png", "next.png", CC_CALLBACK_1(useTicketScene::nextScene, this));
		auto menu_8 = Menu::create(next, NULL);
		menu_8->setPosition(Vec2(size.width / 2, size.height / 2));
		this->addChild(menu_8);

	}

	else
	{
		//�Ի���//////////////////////ѯ���Ƿ�ʹ��Ʊ �˴����޸ģ�ͼƬӦ��Ϊѯ���Ƿ�ʹ��Ʊ/////////////////////////////
		auto hello = Sprite::create("hello.png");
		hello->setPosition(Vec2(400, 320));
		addChild(hello);

		//ȷ��ʹ��
		auto ok = MenuItemImage::create(
			"ok.png",
			"ok.png",
			CC_CALLBACK_1(useTicketScene::okUseTicket, this));
		auto menu_5 = Menu::create(ok, NULL);
		menu_5->setPosition(Vec2(500, 120));
		this->addChild(menu_5);

		//����useTicketScene
		auto returnPaybox = MenuItemImage::create(
			"returnPaybox.png",
			"returnPaybox.png",
			CC_CALLBACK_1(useTicketScene::returnUseTicketScene, this));
		auto menu_6 = Menu::create(returnPaybox, NULL);
		menu_6->setPosition(Vec2(300, 120));
		this->addChild(menu_6);


	}
}

void useTicketScene::returnUseTicketScene(Ref * pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, useTicketScene::createScene()));

}

void useTicketScene::okUseTicket(Ref * pSender)
{
	File file(getTheName(), getPassword());
	if (file.checkTicket())
	{
		file.useTicket();
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, funicularScene::createScene()));
	}

	timecount = CallbackTimeCounter::create();
	this->addChild(timecount);
	timecount->start(11.0f, [=]() //ʱ��Ϊ�˲��Է�����ʱд��5�룬ʵ��ӦΪ120��
	{
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("Your do not have the ticket.\n ", "Arial", 60);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, useTicketScene::createScene()));

	});

}

void useTicketScene::nextScene(Ref * pSender)
{
	leftTime.setTime(-7200+leftTime.getTime());
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SCENE31::createScene()));

}

void useTicketScene::toSecondScene(Ref * pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SecondTollgate_2::createScene()));

}

void useTicketScene::update(float delta)
{
	Node::update(delta);
	auto leftArrow = EventKeyboard::KeyCode::KEY_LEFT_ARROW,
		rightArrow = EventKeyboard::KeyCode::KEY_RIGHT_ARROW;
	if (isKeyPressed(leftArrow))
	{
		keyPressedDuration(leftArrow);
	}
	else if (isKeyPressed(rightArrow))
	{
		keyPressedDuration(rightArrow);
	}
	this->removeChild( uselabeltime);
	std::stringstream ss;
	std::string val;
	ss << int(leftTime.getTime() / 60);
	ss >> val;
	uselabeltime = LabelTTF::create(val, "Arial", 60);
	uselabeltime->setPosition(Vec2(600, 600));
	this->addChild(uselabeltime);

	if (leftTime.setTime(1.0f))
		return;
	else
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SecondTollgate_2::createScene()));
	}

}

bool useTicketScene::isKeyPressed(EventKeyboard::KeyCode keycode)
{
	if (keys[keycode])
	{
		return true;
	}
	else
	{
		return false;
	}
}

void useTicketScene::keyPressedDuration(EventKeyboard::KeyCode code)
{
	int offsetx = 0, offsety = 0;
	switch (code)
	{
	case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
	{offsetx = -5; } break;
	case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:offsetx = 5; break;
	default:offsetx = offsety = 0; break;
	}
	auto moveTo = MoveTo::create(0.3, Vec2(man->getPositionX() + offsetx, man->getPositionY() + offsety));
	man->runAction(moveTo);
}



