#ifndef _BackGround_H_
#define _BackGround_H_

#include"cocos2d.h"
#include"CallbackTimeCounter.h"

using namespace cocos2d;

class BackGround :public Layer
{
public:
	static Scene*  createScene();
	virtual bool init();
	void rollText(float);
	void menuCloseCallback(Ref* pSender);
	CREATE_FUNC(BackGround);
private:
	LabelTTF* text;
	MenuItemImage* menuButton;
	Size visibleSize;
	CallbackTimeCounter* buttonMove;
};
#endif
