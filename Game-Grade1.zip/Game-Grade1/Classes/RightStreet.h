#pragma once
#ifndef _RightStreet_H_
#define _RightStreet_H_

#include"cocos2d.h"
#include"file.h"
#include"MenuScene.h"
#include"FirstTollgate_3.h"
#include"CallbackTimeCounter.h"
#include "Calculagraph.h"
using namespace cocos2d;

class RightStreet :public Layer
{
	friend class FirstTollgate_3;
public:
	CREATE_FUNC(RightStreet);

	RightStreet();
	~RightStreet();
	static Scene* createScene();
	virtual bool init();
	void show_pack(Ref* pSeender);
	void hide_pack(Ref* pSender);
	void to_left_street(Ref* pSender);
	void to_newsstand(Ref*pSender);
	void to_sell_umbrella(Ref*pSender);
	void to_shop(Ref*pSender);
	void buy_newspaper(Ref*pSender);
	void buy_umbrella(Ref* pSender);
	void buy_telescope(Ref* pSender);
	void leave_newsstand(Ref*pSender);
	void leave_shop(Ref*pSender);
	void leave_sell_umbrella(Ref*pSender);
	void update_of_obstruction(float time);//���ó����ֵĶ���
	virtual void update(float dt);
	bool is_hitted();//�ж����Ƿ񱻳�ײ
	void hitted_picture();//���˱���ײ�������ֵĻ���
	void try_again(Ref* pSender);
	void to_menu(Ref* pSender);
	void show_tip(Ref* pSender);
	string getTheName();
	string getPassword();

	float map() {
		isPressed = false;
		isJumped = false;
		moveVec = Vec2(0, 0);
	}

private:
	Size size;
	Sprite* background;
	MenuItemImage* left_street;//��˫���������ťҪ�м�ͷ�ĸо�
	MenuItemImage *pack;//������ť
	Sprite* backpack;//��������
	MenuItemImage* back_to_menu;
	MenuItemImage* tip;
	Sprite* man;
	Sprite* move_car;//�ƶ��ĳ�
	Sprite* die_picture;//����ײ�Ժ���ֵ�ͼƬ
	MenuItemImage* tryagain;
	MenuItemImage* back;
	Sprite *sell_umbrella;
	Sprite *newsstand;
	Sprite *shop;
	bool is_look_tip;
	File file;
	Calculagraph righttime;
	LabelTTF*   rightlabeltime;
	Calculagraph leftTime;


	bool isPressed;
	bool isJumped;
	Vec2 moveVec;
	float jumpVec;
	void onKeyPressed(EventKeyboard::KeyCode keyCode, Event *event);
	void onKeyReleased(EventKeyboard::KeyCode keycode, Event *event);
};
#endif
