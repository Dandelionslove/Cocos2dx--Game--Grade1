#include"FirstTollgate_3.h"
#include"SimpleAudioEngine.h"
#include"MenuScene.h"
#include "Theater.h"
#include<cstdlib>
#include"useTicketScene.h"
#include"TimeCounter.h"
#include "CallbackTimeCounter.h"
#include <fstream>

USING_NS_CC;
using namespace CocosDenshion;

FirstTollgate_3::FirstTollgate_3():file(getTheName(), getPassword())
{
	
}
string FirstTollgate_3::getTheName()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	tempfile >> temp;
	tempfile.close();

	return temp;
}

string FirstTollgate_3::getPassword()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp1;
	string temp;
	tempfile >> temp1;
	tempfile >> temp;
	tempfile.close();
	return temp;
}

FirstTollgate_3::~FirstTollgate_3()
{
}

Scene* FirstTollgate_3::createScene()
{
	auto scene = Scene::create();
	auto layer = FirstTollgate_3::create();
	scene->addChild(layer,1);
	return scene;
}

bool FirstTollgate_3::is_look_tip = false;

bool FirstTollgate_3::init()
{
	if (!Layer::init())
	{
		return false;
	}
	is_look_tip = false;
	size = Director::getInstance()->getVisibleSize();
	SimpleAudioEngine::getInstance()->playBackgroundMusic("noone.mp3", true);//��˫�������������д��Ľ�
	background = Sprite::create("F3_1.png");
	background->setPosition(size.width / 2, size.height / 2);
	background->setScaleY(1.3);
	background->setScaleX(1.3);
	this->addChild(background);
	//float x = background->getPositionX();
	this->man = Sprite::create("man.png");
	this->man->setPosition(ccp(size.width / 2, size.height / 6 + 30));
	this->addChild(man, 10);
	auto keyBoardListener = EventListenerKeyboard::create();
	keyBoardListener->onKeyPressed = CC_CALLBACK_2(FirstTollgate_3::onKeyPressed, this);
	keyBoardListener->onKeyReleased = CC_CALLBACK_2(FirstTollgate_3::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(keyBoardListener, man);


	//�����˵���ť
	back_to_menu = MenuItemImage::create("back_menu.png", "back_menu.png", CC_CALLBACK_1(FirstTollgate_3::to_menu, this));
	tip = MenuItemImage::create("tip.png", "tip.png", CC_CALLBACK_1(FirstTollgate_3::show_tip, this));
	auto menu_1 = Menu::create(tip, back_to_menu, NULL);
	this->addChild(menu_1, 5);
	menu_1->alignItemsVerticallyWithPadding(20);
	menu_1->setPosition(Vec2(50, 80));

	//����һ��������ť
	pack = MenuItemImage::create("pack_button.png", "pack_button.png", CC_CALLBACK_1(FirstTollgate_3::show_pack, this));
	auto menu_3 = Menu::create(pack, NULL);
	this->addChild(menu_3, 70);
	menu_3->setPosition(50, 170);

	move_car = Sprite::create("car.png");
	this->addChild(move_car, 10);
	move_car->setPosition(ccp(-100, size.height / 5 - 40));
	//·�������ܶ�
	this->schedule(schedule_selector(FirstTollgate_3::update_of_obstruction), 8.0f);//��˫���������ֵ�ʱ��ɵ�
	this->scheduleUpdate();

	//������Ժ��ť
	auto theater = MenuItemImage::create("theater.png", "theater.png", CC_CALLBACK_1(FirstTollgate_3::to_theater, this));
	auto theater_button = Menu::create(theater, NULL);
	this->addChild(theater_button, 0);
	theater_button->setPosition(170, 220);

	//������Ʊ����ť
	auto paybox = MenuItemImage::create("paybox.png", "paybox.png", CC_CALLBACK_1(FirstTollgate_3::to_payboxScene, this));
	auto paybox_button = Menu::create(paybox, NULL);
	this->addChild(paybox_button);
	paybox_button->setPosition(800, 160);//��˫����ͼƬ����λ�����

										 //������ͷָ���ұֵ߽�
	right_street = MenuItemImage::create("right.png", "right.png", CC_CALLBACK_1(FirstTollgate_3::to_right_street, this));
	auto right_button = Menu::create(right_street, NULL);
	this->addChild(right_button);
	right_button->setPosition(800, 500);
	return true;
}

	void FirstTollgate_3::onKeyPressed(EventKeyboard::KeyCode keyCode, Event *event)
	{
		isPressed = true;
		switch (keyCode) {
		case EventKeyboard::KeyCode::KEY_A:
		case EventKeyboard::KeyCode::KEY_CAPITAL_A:
		case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
		{
			if (man->getPositionX()>390)
				moveVec = Vec2(-30, 0);//��˫������ʱ�����update�������޸�
		}
		break;
		case EventKeyboard::KeyCode::KEY_D:
		case EventKeyboard::KeyCode::KEY_CAPITAL_D:
		case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
		{
			if (man->getPositionX()<930)
				moveVec = Vec2(30, 0);//��˫������ʱ�����update�������޸�
		}
		break;
		case EventKeyboard::KeyCode::KEY_W:
		case EventKeyboard::KeyCode::KEY_CAPITAL_W:
		case EventKeyboard::KeyCode::KEY_UP_ARROW:
			if (!isJumped&&man->getPositionY() < 200)
			{
				jumpVec = 50.0;
				isJumped = true;
				auto jump = JumpBy::create(1.0f, Vec2(0, 0), jumpVec, 1);
				auto callFunc = CallFunc::create([=]() {
					isJumped = false;
				});
				man->runAction(Sequence::create(jump, callFunc, NULL));
			}	break;
		default:
			break;
		}
		man->runAction(MoveBy::create(0.2, moveVec));

		return;
	}

void FirstTollgate_3::onKeyReleased(EventKeyboard::KeyCode keycode, Event * event)
{
	isPressed = false;
	isJumped = false;
	moveVec = Vec2(0, 0);
	jumpVec = 0.0;
}

void FirstTollgate_3::try_again(Ref* pSender)
{
	leftTime.setTime(-7200 + leftTime.getTime());
	file.looseHeart();
	if (file.checkHeart()>=1)
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, FirstTollgate_3::createScene()));
	}
	else
	{
		file.clearData();
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, MenuScene::createScene()));
	}
}

void FirstTollgate_3::to_menu(Ref* pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f,MenuScene::createScene()));
}

void FirstTollgate_3::show_tip(Ref* pSender)
{
	if (is_look_tip)
	{
		return;
	}
	this->is_look_tip = true;
	auto tip = Sprite::create("tiptext.png");//��˫������ʾ
	this->addChild(tip);
	tip->setPosition(size.width / 2, size.height - 100);
	CallbackTimeCounter* _tip = CallbackTimeCounter::create();
	this->addChild(_tip);
	_tip->start(5.0f, [=]()
	{
		this->removeChild(tip);
	});
}

//�������� ��˫������Ҫ����ģ����ͼƬ����ʱ���д����
void FirstTollgate_3::show_pack(Ref * pSender)
{
	backpack = Sprite::create("backpack.png");
	this->addChild(backpack);
	backpack->setPosition(size.width / 2, size.height / 2);
	auto pack_menu = Menu::create();
	backpack->addChild(pack_menu);
	pack_menu->setPosition(size.width / 2, size.height / 2);
	//�����ֵı���////////////////��˫�����ȴ��������ж�����ͼƬ��������ע��������ʹ�ð�ť����������Ϊ0����ʹ�ð�ť����////////////////////////////
	//////////////////////////////////��˫�����Ժ��ÿһ���ؿ������ϱ���////////////////////////////////////////////////
	////��˫��������֤
	//auto IDcard = ::create("IDcard2.png");
	//backpack->addChild(IDcard, 1);
	//IDcard->setPosition(150, 350);
	////��˫����Ǯ��
	//Value _money = Value(file.getMoney());
	//Value v = Value("Money Number: ");
	//string num = v.asString() + _money.asString();
	//auto money_num = CCLabelTTF::create(num, "Arial", 20);
	//backpack->addChild(money_num, 10);
	//money_num->setPosition(150, 300);
	//money_num->setColor(Color3B(0, 0, 0));//��˫�������õ�������ɫ���ɸ�

	//											//��˫��������������������
	//auto things_name = Sprite::create("things_name.png");
	//auto number = Sprite::create("number.png");
	//backpack->addChild(things_name);
	//backpack->addChild(number);
	//things_name->setPosition(150, 400);
	//number->setPosition(450, 400);

	////��˫����Ʊ
	//auto ticket = Sprite::create("ticket.png");
	//backpack->addChild(ticket, 1);
	//ticket->setPosition(150, 250);
	//Value num_1 = Value(file.checkTicket());
	//auto ticket_num = CCLabelTTF::create(num_1.asString(), "Arial", 20);
	//ticket->addChild(ticket_num);
	//ticket_num->setPosition(400, 250);
	//ticket_num->setColor(Color3B(0, 0, 0));
	////��˫�����ֻ�
	//auto phone = Sprite::create("phone.png");
	//backpack->addChild(phone, 1);
	//phone->setPosition(150, 180);
	//phone->setScale(0.3f);
	//auto phone_num = CCLabelTTF::create("1", "Arial", 20);
	//phone->addChild(phone_num);
	//phone_num->setPosition(500, 175);
	//phone_num->setScale(5);
	//phone_num->setColor(Color3B(0, 0, 0));
	//// ��˫������ֽ
	//auto newspaper = Sprite::create("newspaper.png");
	//backpack->addChild(newspaper);
	//newspaper->setPosition(150, 140);
	//Value num_2 = Value(file.checkNewspaper());
	//auto newspaper_num = CCLabelTTF::create(num_2.asString(), "Arial", 20);
	//newspaper->addChild(newspaper_num);
	//newspaper_num->setColor(Color3B(0, 0, 0));
	//newspaper_num->setPosition(420, 140);
	////��˫������Զ��
	//auto telescope = Sprite::create("telescope.png");
	//backpack->addChild(telescope);
	//telescope->setPosition(150, 100);
	//Value num_3 = Value(file.checkTelescope());
	//auto telescope_num = CCLabelTTF::create(num_3.asString(), "Arial", 20);
	//telescope->addChild(telescope_num);
	//telescope_num->setColor(Color3B(0, 0, 0));
	//telescope_num->setPosition(450, 100);
	////��˫������ɡ
	//auto umbrella = Sprite::create("umbrella3.png");
	//backpack->addChild(umbrella);
	//umbrella->setPosition(130, 60);
	//Value num_4 = Value(file.checkUmbrella());
	//auto umbrella_num = CCLabelTTF::create(num_3.asString(), "Arial", 20);
	//umbrella->addChild(umbrella_num);
	//umbrella_num->setColor(Color3B(0, 0, 0));
	//umbrella_num->setPosition(130, 60);

	//��������
	Value de = Value("\n");
	Value d_1 = Value("IDcard: Father ");
	Value d_2 = Value("Life Number: "); Value v_2 = Value(file.checkHeart());
	Value d_3 = Value("Money: "); Value v_3 =Value( file.getMoney());
	Value d_4 = Value("Telescope: "); Value v_4 = Value(file.checkTelescope());
	Value d_5 = Value("Ticket: "); Value v_5 = Value(file.checkTicket());
	Value d_6 = Value("Umbrella: "); Value v_6 = Value(file.checkUmbrella());
	Value d_7 = Value("Newspaper: "); Value v_7 = Value(file.checkNewspaper());
	string  pack_content = d_1.asString() + de.asString() + d_2.asString() + v_2.asString() + de.asString() + d_3.asString() + v_3.asString() + de.asString() + d_4.asString() + v_4.asString() + de.asString() + d_5.asString() + v_5.asString() + de.asString() + d_6.asString() + v_6.asString() + de.asString() + d_7.asString() + v_7.asString() + de.asString();
	auto _pack_content = CCLabelTTF::create(pack_content, "UWJACK8", 40);
	backpack->addChild(_pack_content, 5);
	_pack_content->setPosition(350, 200);
	/*Value life= Value(file.checkHeart());
	Value d = Value("Life Number: ");

	string  life_num = d.asString() + life.asString();
	auto _life_num = CCLabelTTF::create(life_num, "Arial", 20);
	backpack->addChild(_life_num,15);
	_life_num->setColor(Color3B(0, 0, 0));
	_life_num->setPosition(120, 200);*/

	////��˫����������Ϸ����İ�ť
	auto back_scene = MenuItemImage::create("back_scene.png", "back_scene.png", CC_CALLBACK_1(FirstTollgate_3::hide_pack, this));
	auto back_scene_button = Menu::create(back_scene, NULL);
	backpack->addChild(back_scene_button);
	back_scene_button->setPosition(400, 30);


}

void FirstTollgate_3::hide_pack(Ref * pSender)
{
	this->removeChild(backpack);
}

void FirstTollgate_3::update_of_obstruction(float time)
{

	move_car->setPosition(ccp(-100, 140));
	setAnchorPoint(ccp(1, 0.5));
	auto move = MoveTo::create(4.0f, Point(1100, size.height / 5));
	move_car->runAction(move);

	
}

bool FirstTollgate_3::is_hitted()
{
	float x1 = man->getPositionX(), x2 = move_car->getPositionX() ;
	float y1 = man->getPositionY(), y2 = move_car->getPositionY();
	if (fabs(x1-x2)<100)//�ж����복λ��
	{
		if (fabs(y1-y2)<50)//��˫�������޸�
		{
			return true;
		}
	}
	return false;
}

void FirstTollgate_3::update(float dt)
{
	if (this->is_hitted())//��˫�����ж����Ƿ�ײ������ײ���������ȥ��ʧ�ܻ���
	{
		this->hitted_picture();
		this->unscheduleUpdate();//�˴��Ժ󳵻����ܣ��Ǻ�����
	}

	this->removeChild(labelTime);
	std::stringstream ss;
	std::string val;
	ss << int(leftTime.getTime() / 60);
	ss >> val;
	labelTime = LabelTTF::create(val, "UWJACK8", 60);
	labelTime->setPosition(Vec2(600, 600));
	this->addChild(labelTime);

	if (leftTime.setTime(1.0f))
		return;
	else
	{
		timeOver();
		return;
	}
}

void FirstTollgate_3::hitted_picture()
{
	this->setSwallowsTouches(true);
	move_car->stopAllActions();
	//�˴��ɲ���unschedule(schedule_selector(````));
	man->setOpacity(0);
	die_picture = Sprite::create("die_picture.png");//��˫����ͼƬ���
	this->addChild(die_picture, 100);
	die_picture->setPosition(size.width / 2, size.height / 2);

	auto try_againScene = Sprite::create("try_againScene.png");
	try_againScene->setPosition(Vec2(470, 320));
	addChild(try_againScene,90);

	tryagain = MenuItemImage::create("try again.png", "try again.png", CC_CALLBACK_1(FirstTollgate_3::try_again, this));
	back = MenuItemImage::create("back_menu.png", "back_menu.png", CC_CALLBACK_1(FirstTollgate_3::to_menu, this));
	auto die_menu = Menu::create(tryagain, back, NULL);
	die_picture->addChild(die_menu);
	die_menu->setPosition(460, 130);
	die_menu->alignItemsVerticallyWithPadding(5);
}

void FirstTollgate_3::to_theater(Ref * pSender)
{
	if (file.checkTicket())
	{
		SimpleAudioEngine::getInstance()->stopBackgroundMusic("Xt.mp3");
		file.useTicket();
		Director::getInstance()->pushScene(Theater::createScene());
	}
	else
	{
		auto timecount = CallbackTimeCounter::create();
		this->addChild(timecount);
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("You are not admitted.\n ", "UWJACK8", 40);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);
		timecount->start(2.0f, [=]()
		{
			this->removeChild(tip);
		});

	}
}

void FirstTollgate_3::to_right_street(Ref * pSender)
{
	Director::getInstance()->pushScene(RightStreet::createScene());
}

void FirstTollgate_3::to_payboxScene(Ref * pSender)
{
	Director::getInstance()->pushScene(payboxSceneFirst::createScene());
}

void FirstTollgate_3::timeOver()
{
	File file(getTheName(), getPassword());

	Size size = Director::getInstance()->getVisibleSize();
	auto die_picture = Sprite::create("die_picture.png");//��˫����ͼƬ��ģ��˴���Ϊ��ʯͷ�����Ļ���
	this->addChild(die_picture, 200);
	die_picture->setPosition(Vec2(470, 320));


	MenuItemImage* tryagain = MenuItemImage::create("tryAgain.png", "tryAgain.png", CC_CALLBACK_1(FirstTollgate_3::try_again, this));
	MenuItemImage* back = MenuItemImage::create("menu.png", "menu.png", CC_CALLBACK_1(FirstTollgate_3::to_menu, this));
	auto menu_2 = Menu::create(tryagain, back, NULL);
	die_picture->addChild(menu_2, 290);
	menu_2->setPosition(Vec2(470, 170));
	menu_2->alignItemsVerticallyWithPadding(10);
}




 
