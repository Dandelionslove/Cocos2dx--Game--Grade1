#include <fstream>

#include"RightStreet.h"
#include"SimpleAudioEngine.h"
#include"shopSceneFirst.h"

USING_NS_CC;
using namespace CocosDenshion;

RightStreet::RightStreet():is_look_tip(FirstTollgate_3::is_look_tip), file(getTheName(), getPassword())
{
}

RightStreet::~RightStreet()
{
}

Scene * RightStreet::createScene()
{
	auto scene = Scene::create();
	auto layer = RightStreet::create();
	scene->addChild(layer, 1);
	return scene;
}

bool RightStreet::init()
{
	if (!Layer::init())
	{
		return false;
	}

	size = Director::getInstance()->getVisibleSize();
	//SimpleAudioEngine::getInstance()->playBackgroundMusic("meetloop.mp3");//��˫�����������֣��ɸ�
	//�󱳾�ͼ
	background = Sprite::create("F3_2.png");
	this->addChild(background, 0);
	background->setPosition(size.width / 2, size.height / 2 + 20);
	//ָ����ֵ߽��ļ�ͷ��ť ��˫�����ɸ�ͼƬ��λ��
	left_street = MenuItemImage::create("left.png", "left.png", CC_CALLBACK_1(RightStreet::to_left_street, this));
	auto left_button = Menu::create(left_street, NULL);
	this->addChild(left_button);
	left_button->setPosition(90, 520);
	//�����˵���ť
	back_to_menu = MenuItemImage::create("back_menu.png", "back_menu.png", CC_CALLBACK_1(RightStreet::to_menu, this));
	tip = MenuItemImage::create("tip.png", "tip.png", CC_CALLBACK_1(RightStreet::show_tip, this));
	auto menu_1 = Menu::create(tip, back_to_menu, NULL);
	this->addChild(menu_1, 15);
	menu_1->alignItemsVerticallyWithPadding(20);
	menu_1->setPosition(Vec2(50, 250));
	//�ֵ����ݣ�����ͤ����ɡ���̵�,��˫�����˴��ĵ绰ֻͤ�ǻ����ϵ�һ����������
	//����ͤ
	auto newsstand = MenuItemImage::create("newsstand.png", "newsstand.png",CC_CALLBACK_1(RightStreet::to_newsstand,this));//��˫��������ͤ��ͼƬ�ɸ�
	auto newsstand_button = Menu::create(newsstand, NULL);
	this->addChild(newsstand_button);
	newsstand_button->setPosition(200, 170);
	//��ɡ��
	auto sell_umbrella = MenuItemImage::create("sell_umbrella.png", "sell_umbrella.png", CC_CALLBACK_1(RightStreet::to_sell_umbrella, this));
	auto sell_umbrella_button = Menu::create(sell_umbrella, NULL);
	this->addChild(sell_umbrella_button);
	sell_umbrella_button->setPosition(800, 200);
	//�̵�
	auto shop = MenuItemImage::create("shop.png", "shop.png", CC_CALLBACK_1(RightStreet::to_shop, this));
	auto shop_button = Menu::create(shop, NULL);
	this->addChild(shop_button);
	shop_button->setPosition(500, 170);
	//�˵���ť�����ز˵�����������ʾ���˴���ʾ���󳡾����ж�����ϵ��
	//����һ��������ť
	pack = MenuItemImage::create("pack_button.png", "pack_button.png", CC_CALLBACK_1(RightStreet::show_pack, this));
	auto menu_3 = Menu::create(pack, NULL);
	this->addChild(menu_3, 5);
	menu_3->setPosition(50, 180);

	//����man
	man = Sprite::create("man.png");
	this->addChild(man, 300);
	man->setPosition(300, 150);

	move_car = Sprite::create("car.png");
	this->addChild(move_car, 10);
	move_car->setPosition(ccp(-100, size.height / 5 + 20));
	//·�������ܶ�
	this->schedule(schedule_selector(RightStreet::update_of_obstruction), 8.0f);//��˫���������ֵ�ʱ��ɵ�
	this->scheduleUpdate();
	//�����ƶ�
	auto keyBoardListener = EventListenerKeyboard::create();
	keyBoardListener->onKeyPressed = CC_CALLBACK_2(RightStreet::onKeyPressed, this);
	keyBoardListener->onKeyReleased = CC_CALLBACK_2(RightStreet::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(keyBoardListener, man);
	return true;
}

void RightStreet::to_left_street(Ref * pSender)
{
	Director::getInstance()->popScene();
}

//��˫����ȥ������ͤ�����˱�ֽ�Ժ󣬱�ֽ�ϻ������Ժ�йص����ţ�Ҳ����������ͼƬ��λ�ô���
void RightStreet::to_newsstand(Ref * pSender)
{
	newsstand = Sprite::create("shopBG.png");
	this->addChild(newsstand,20);//��˫��������Ժ��ͼ����ܸ��ǻ���
	newsstand->setPosition(size.width / 2, size.height / 2);
	auto worker = Sprite::create("worker.png");
	newsstand->addChild(worker);
	worker->setPosition(300, 80);
	auto saying = Sprite::create("saying_1.png");
	worker->addChild(saying);
	saying->setPosition(300, 200);
	//�����ش�ť
	auto ok = MenuItemImage::create("ok.png", "ok.png", CC_CALLBACK_1(RightStreet::buy_newspaper, this));
	auto no = MenuItemImage::create("no.png", "no.png", CC_CALLBACK_1(RightStreet::leave_newsstand, this));
	auto answer_menu = Menu::create(ok, no, NULL);
	newsstand->addChild(answer_menu);
	answer_menu->setPosition(800, 100);
	answer_menu->alignItemsVerticallyWithPadding(100);
	
}
//��˫����ȥ����ɡ�ĵط�
void RightStreet::to_sell_umbrella(Ref * pSender)
{
	sell_umbrella = Sprite::create("shopBG.png");
	this->addChild(sell_umbrella,20);
	sell_umbrella->setPosition(size.width / 2, size.height / 2);
	auto worker = Sprite::create("worker.png");
	sell_umbrella->addChild(worker);
	worker->setPosition(330,100);
	auto saying = Sprite::create("saying_2.png");
	worker->addChild(saying);
	saying->setPosition(300, 270);
	//�����ش�ť
	auto ok = MenuItemImage::create("ok.png", "ok.png", CC_CALLBACK_1(RightStreet::buy_umbrella, this));
	auto no = MenuItemImage::create("no.png", "no.png", CC_CALLBACK_1(RightStreet::leave_sell_umbrella, this));
	auto answer_menu = Menu::create(ok, no, NULL);
	sell_umbrella->addChild(answer_menu);
	answer_menu->setPosition(800, 100);
	answer_menu->alignItemsVerticallyWithPadding(100);
}

//��˫����ȥ���̵�,��Ҫ����Զ��
void RightStreet::to_shop(Ref * pSender)
{
	Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f, shopSceneFirst::createScene()));

}
//��˫������ֽ�������������
void RightStreet::buy_newspaper(Ref * pSender)
{
	if (file.checkNewspaper())
	{
		auto buy_it = CCLabelTTF::create("You have bought an newspaper successfully!", "Arial", 20);
		newsstand->addChild(buy_it, 5);
		buy_it->setPosition(300, 200);
		buy_it->setColor(Color3B(255,255,255));
		auto move = MoveTo::create(5.0f, Point(300, 300));
		buy_it->runAction(move);
		auto remove = CallbackTimeCounter::create();
		newsstand->addChild(remove);
		remove->start(3.0f, [=]()
		{
			newsstand->removeChild(buy_it, true);
		});
	}
	int price = 1000;
	if (!(file.checkNewspaper()) && file.getMoney() <  price)
	{
		auto fail_to_buy = CCLabelTTF::create("Sorry!Your money is not enough!", "Arial", 20);
		newsstand->addChild(fail_to_buy);
		fail_to_buy->setPosition(300, 200);
		auto move = MoveTo::create(5.0f, Point(300, 300));
		fail_to_buy->runAction(move);
		auto remove = CallbackTimeCounter::create();
		newsstand->addChild(remove);
		remove->start(3.0f, [=]()
		{
			newsstand->removeChild(fail_to_buy, true);
		});
	}
	if (!(file.checkNewspaper()) && file.getMoney() >= price)
	{
		file.buyNewspaper();
		file.moneyDecrease(price);
		auto buy_it = CCLabelTTF::create("You buy an newspaper successfully!", "Arial", 20);
		newsstand->addChild(buy_it, 5);
		buy_it->setPosition(300, 200);
		auto move = MoveTo::create(5.0f, Point(300, 300));
		buy_it->runAction(move);
		auto remove = CallbackTimeCounter::create();
		newsstand->addChild(remove);
		remove->start(3.0f, [=]()
		{
			newsstand->removeChild(buy_it, true);
		});

	}
}

void RightStreet::buy_umbrella(Ref * pSender)
{
	if (file.checkUmbrella())
	{
		auto buy_it = CCLabelTTF::create("You have bought an umbrella successfully!", "Arial", 20);
		sell_umbrella->addChild(buy_it, 5);
		buy_it->setPosition(300, 200);
		buy_it->setColor(Color3B(255,255,255));
		auto move = MoveTo::create(5.0f, Point(300, 300));
		buy_it->runAction(move);
		auto remove = CallbackTimeCounter::create();
		sell_umbrella->addChild(remove);
		remove->start(3.0f, [=]()
		{
			sell_umbrella->removeChild(buy_it, true);
		});
	}
	int price = 2000;
	if(!(file.checkUmbrella())&&file.getMoney() <  price)
	{
		auto fail_to_buy = CCLabelTTF::create("Sorry!Your money is not enough!", "Arial", 20);
		sell_umbrella->addChild(fail_to_buy);
		fail_to_buy->setPosition(300, 200);
		fail_to_buy->setColor(Color3B(255,255,255));
		auto move = MoveTo::create(5.0f, Point(300, 300));
		fail_to_buy->runAction(move);
		auto remove = CallbackTimeCounter::create();
		sell_umbrella->addChild(remove);
		remove->start(3.0f, [=]()
		{
			sell_umbrella->removeChild(fail_to_buy, true);
		});
	}
	if (!(file.checkUmbrella()) && file.getMoney() >= price)
	{
		file.moneyDecrease(price);
		file.buyUmbrella();
		auto buy_it = CCLabelTTF::create("You buy an umbrella successfully!", "Arial", 20);
		sell_umbrella->addChild(buy_it, 5);
		buy_it->setPosition(300, 200);
		buy_it->setColor(Color3B(255,255,255));
		auto move = MoveTo::create(5.0f, Point(300, 300));
		buy_it->runAction(move);
		auto remove = CallbackTimeCounter::create();
		sell_umbrella->addChild(remove);
		remove->start(3.0f, [=]()
		{
			sell_umbrella->removeChild(buy_it, true);
		});

	}
}

void RightStreet::buy_telescope(Ref * pSender)
{
	this->file.buyTelescope();
	if (file.checkTelescope())
	{
		auto buy_it = CCLabelTTF::create("You have bought a telescope successfully!", "Arial", 20);
		shop->addChild(buy_it, 5);
		buy_it->setPosition(300, 200);
		buy_it->setColor(Color3B(0, 0, 0));
		auto move = MoveTo::create(5.0f, Point(300, 300));
		buy_it->runAction(move);
		auto remove = CallbackTimeCounter::create();
		shop->addChild(remove);
		remove->start(5.2f, [=]()
		{
			shop->removeChild(buy_it, true);
		});
	}
	else
	{
		auto fail_to_buy = CCLabelTTF::create("Sorry!Your money is not enough!", "Arial", 20);
		shop->addChild(fail_to_buy);
		fail_to_buy->setPosition(300, 200);
		fail_to_buy->setColor(Color3B(0, 0, 0));
		auto move = MoveTo::create(1.5f, Point(300, 300));
		fail_to_buy->runAction(move);
		auto remove = CallbackTimeCounter::create();
		shop->addChild(remove);
		remove->start(1.8f, [=]()
		{
			shop->removeChild(fail_to_buy,true);
		});
	}
}

void RightStreet::leave_newsstand(Ref * pSender)
{
	this->removeChild(newsstand);
}

void RightStreet::leave_shop(Ref * pSender)
{
	this->removeChild(shop);
}

void RightStreet::leave_sell_umbrella(Ref * pSender)
{
	this->removeChild(sell_umbrella);
}

//�������� ��˫������Ҫ����ģ����ͼƬ����ʱ���д����
void RightStreet::show_pack(Ref * pSender)
{
	backpack = Sprite::create("backpack.png");
	this->addChild(backpack);
	backpack->setPosition(size.width / 2, size.height / 2);
	auto pack_menu = Menu::create();
	backpack->addChild(pack_menu,300);
	pack_menu->setPosition(size.width / 2, size.height / 2);
	//�����ֵı���////////////////��˫�����ȴ��������ж�����ͼƬ��������ע��������ʹ�ð�ť����������Ϊ0����ʹ�ð�ť����////////////////////////////
	//////////////////////////////////��˫�����Ժ��ÿһ���ؿ������ϱ���////////////////////////////////////////////////
	////��˫��������֤
	//auto IDcard = ::create("IDcard2.png");
	//backpack->addChild(IDcard, 1);
	//IDcard->setPosition(150, 350);
	////��˫����Ǯ��
	//Value _money = Value(file.getMoney());
	//Value v = Value("Money Number: ");
	//string num = v.asString() + _money.asString();
	//auto money_num = CCLabelTTF::create(num, "Arial", 20);
	//backpack->addChild(money_num, 10);
	//money_num->setPosition(150, 300);
	//money_num->setColor(Color3B(0, 0, 0));//��˫�������õ�������ɫ���ɸ�

	//											//��˫��������������������
	//auto things_name = Sprite::create("things_name.png");
	//auto number = Sprite::create("number.png");
	//backpack->addChild(things_name);
	//backpack->addChild(number);
	//things_name->setPosition(150, 400);
	//number->setPosition(450, 400);

	////��˫����Ʊ
	//auto ticket = Sprite::create("ticket.png");
	//backpack->addChild(ticket, 1);
	//ticket->setPosition(150, 250);
	//Value num_1 = Value(file.checkTicket());
	//auto ticket_num = CCLabelTTF::create(num_1.asString(), "Arial", 20);
	//ticket->addChild(ticket_num);
	//ticket_num->setPosition(400, 250);
	//ticket_num->setColor(Color3B(0, 0, 0));
	////��˫�����ֻ�
	//auto phone = Sprite::create("phone.png");
	//backpack->addChild(phone, 1);
	//phone->setPosition(150, 180);
	//phone->setScale(0.3f);
	//auto phone_num = CCLabelTTF::create("1", "Arial", 20);
	//phone->addChild(phone_num);
	//phone_num->setPosition(500, 175);
	//phone_num->setScale(5);
	//phone_num->setColor(Color3B(0, 0, 0));
	//// ��˫������ֽ
	//auto newspaper = Sprite::create("newspaper.png");
	//backpack->addChild(newspaper);
	//newspaper->setPosition(150, 140);
	//Value num_2 = Value(file.checkNewspaper());
	//auto newspaper_num = CCLabelTTF::create(num_2.asString(), "Arial", 20);
	//newspaper->addChild(newspaper_num);
	//newspaper_num->setColor(Color3B(0, 0, 0));
	//newspaper_num->setPosition(420, 140);
	////��˫������Զ��
	//auto telescope = Sprite::create("telescope.png");
	//backpack->addChild(telescope);
	//telescope->setPosition(150, 100);
	//Value num_3 = Value(file.checkTelescope());
	//auto telescope_num = CCLabelTTF::create(num_3.asString(), "Arial", 20);
	//telescope->addChild(telescope_num);
	//telescope_num->setColor(Color3B(0, 0, 0));
	//telescope_num->setPosition(450, 100);
	////��˫������ɡ
	//auto umbrella = Sprite::create("umbrella3.png");
	//backpack->addChild(umbrella);
	//umbrella->setPosition(130, 60);
	//Value num_4 = Value(file.checkUmbrella());
	//auto umbrella_num = CCLabelTTF::create(num_3.asString(), "Arial", 20);
	//umbrella->addChild(umbrella_num);
	//umbrella_num->setColor(Color3B(0, 0, 0));
	//umbrella_num->setPosition(130, 60);

	//��������
	Value de = Value("\n");
	Value d_1 = Value("IDcard: Father ");
	Value d_2 = Value("Life Number: "); Value v_2 = Value(file.checkHeart());
	Value d_3 = Value("Money: "); Value v_3 = Value(file.getMoney());
	Value d_4 = Value("Telescope: "); Value v_4 = Value(file.checkTelescope());
	Value d_5 = Value("Ticket: "); Value v_5 = Value(file.checkTicket());
	Value d_6 = Value("Umbrella: "); Value v_6 = Value(file.checkUmbrella());
	Value d_7 = Value("Newspaper: "); Value v_7 = Value(file.checkNewspaper());
	string  pack_content = d_1.asString() + de.asString() + d_2.asString() + v_2.asString() + de.asString() + d_3.asString() + v_3.asString() + de.asString() + d_4.asString() + v_4.asString() + de.asString() + d_5.asString() + v_5.asString() + de.asString() + d_6.asString() + v_6.asString() + de.asString() + d_7.asString() + v_7.asString() + de.asString();
	auto _pack_content = CCLabelTTF::create(pack_content, "UWJACK8", 40);
	backpack->addChild(_pack_content, 5);
	_pack_content->setPosition(350, 200);
	/*Value life= Value(file.checkHeart());
	Value d = Value("Life Number: ");

	string  life_num = d.asString() + life.asString();
	auto _life_num = CCLabelTTF::create(life_num, "Arial", 20);
	backpack->addChild(_life_num,15);
	_life_num->setColor(Color3B(0, 0, 0));
	_life_num->setPosition(120, 200);*/

	////��˫����������Ϸ����İ�ť
	auto back_scene = MenuItemImage::create("back_scene.png", "back_scene.png", CC_CALLBACK_1(RightStreet::hide_pack, this));
	auto back_scene_button = Menu::create(back_scene, NULL);
	backpack->addChild(back_scene_button);
	back_scene_button->setPosition(400, 30);


}

void RightStreet::hide_pack(Ref * pSender)
{
	this->removeChild(backpack);
}

void RightStreet::update_of_obstruction(float time)
{
	move_car->setPosition(ccp(-100, size.height / 5));
	auto move = MoveTo::create(4.0f, Point(1100, size.height / 5));
	move_car->runAction(move);
}

void RightStreet::update(float dt)
{
	if (is_hitted())//��˫�����ж����Ƿ�ײ������ײ���������ȥ��ʧ�ܻ���
	{
		this->hitted_picture();
		this->unscheduleUpdate();//�˴��Ժ󳵻����ܣ��Ǻ�����
	}

	this->removeChild(rightlabeltime);
	std::stringstream ss;
	std::string val;
	ss << int(leftTime.getTime() / 60);
	ss >> val;
	rightlabeltime = LabelTTF::create(val, "UWJACK8", 60);
	rightlabeltime->setPosition(Vec2(600, 600));
	this->addChild(rightlabeltime);

	if (leftTime.setTime(1.0f))
		return;
	else
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, FirstTollgate_3::createScene()));
		return;
	}

}

bool RightStreet::is_hitted()
{
	float x1 = man->getPositionX(), x2 = move_car->getPositionX();
	float y1 = man->getPositionY(), y2 = move_car->getPositionY();
	if (fabs(x1 - x2)<100)//�ж����복λ��
	{
		if (fabs(y1 - y2)<50)//��˫�������޸�
		{
			return true;
		}
	}
	return false;
}

void RightStreet::hitted_picture()
{
	this->setSwallowsTouches(true);
	move_car->stopAllActions();
	//�˴��ɲ���unschedule(schedule_selector(````));
	man->setOpacity(0);
	die_picture = Sprite::create("die_picture.png");//��˫����ͼƬ���
	this->addChild(die_picture, 100);
	die_picture->setPosition(size.width / 2, size.height / 2);

	auto try_againScene = Sprite::create("try_againScene.png");
	try_againScene->setPosition(Vec2(470, 320));
	addChild(try_againScene,90);

	tryagain = MenuItemImage::create("try again.png", "try again.png", CC_CALLBACK_1(RightStreet::try_again, this));
	back = MenuItemImage::create("back_menu.png", "back_menu.png", CC_CALLBACK_1(RightStreet::to_menu, this));
	auto die_menu = Menu::create(tryagain, back, NULL);
	die_picture->addChild(die_menu);
	die_menu->setPosition(430, 200);
	die_menu->alignItemsVerticallyWithPadding(5);
}

void RightStreet::try_again(Ref* pSender)
{
	File file(getTheName(), getPassword());
	leftTime.setTime(-7200 + leftTime.getTime());
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, FirstTollgate_3::createScene()));
}

string RightStreet::getTheName()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	tempfile >> temp;
	tempfile.close();

	return temp;
}

string RightStreet::getPassword()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp1;
	string temp;
	tempfile >> temp1;
	tempfile >> temp;
	tempfile.close();
	return temp;
}

void RightStreet::to_menu(Ref* pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, MenuScene::createScene()));
}

void RightStreet::show_tip(Ref * pSender)
{
	if (is_look_tip)
	{
		return;
	}
	this->is_look_tip = true;
	auto tip = Sprite::create("tiptext.png");//��˫������ʾ
	this->addChild(tip);
	tip->setPosition(size.width / 2, size.height - 100);
	CallbackTimeCounter* _tip = CallbackTimeCounter::create();
	this->addChild(_tip);
	_tip->start(5.0f, [=]()
	{
		this->removeChild(tip);
	});
}

void RightStreet::onKeyPressed(EventKeyboard::KeyCode keyCode, Event *event)
{
	isPressed = true;
	switch (keyCode) {
	case EventKeyboard::KeyCode::KEY_A:
	case EventKeyboard::KeyCode::KEY_CAPITAL_A:
	case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
	{
		if (man->getPositionX()>30)
			moveVec = Vec2(-30, 0);//��˫������ʱ�����update�������޸�
	}
	break;
	case EventKeyboard::KeyCode::KEY_D:
	case EventKeyboard::KeyCode::KEY_CAPITAL_D:
	case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
	{
		if (man->getPositionX()<930)
			moveVec = Vec2(30, 0);//��˫������ʱ�����update�������޸�
	}
	break;
	case EventKeyboard::KeyCode::KEY_W:
	case EventKeyboard::KeyCode::KEY_CAPITAL_W:
	case EventKeyboard::KeyCode::KEY_UP_ARROW:
		if (!isJumped&&man->getPositionY() < 200)
		{
			jumpVec = 50.0;
			isJumped = true;
			auto jump = JumpBy::create(1.0f, Vec2(0, 0), jumpVec, 1);
			auto callFunc = CallFunc::create([=]() {
				isJumped = false;
			});
			man->runAction(Sequence::create(jump, callFunc, NULL));
		}	break;
	default:
		break;
	}
	man->runAction(MoveBy::create(0.2, moveVec));

	return;
}

void RightStreet::onKeyReleased(EventKeyboard::KeyCode keycode, Event * event)
{
	isPressed = false;
	isJumped = false;
	moveVec = Vec2(0, 0);
	jumpVec = 0.0;
}
