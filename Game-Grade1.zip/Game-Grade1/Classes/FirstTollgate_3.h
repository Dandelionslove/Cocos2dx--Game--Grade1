#pragma once
#ifndef _FirstTollgate_3_H_
#define _FirstTollgate_3_H_

#include"cocos2d.h"
#include"SecondTollgate_1.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"SimpleAudioEngine.h"
#include"TimeCounter.h"
#include"CallbackTimeCounter.h"
#include"file.h"
#include"RightStreet.h"
#include"payboxSceneFirst.h"
#include "Calculagraph.h"
using namespace cocos2d;
using namespace std;
using namespace ui;

class FirstTollgate_3 :public Layer
{
public:
	CREATE_FUNC(FirstTollgate_3);
	FirstTollgate_3();
	~FirstTollgate_3();

	static Scene* createScene();
	virtual bool init();
	void try_again(Ref* pSender);
	void to_menu(Ref* pSender);
	void show_tip(Ref* pSender);
	float map() {
		isPressed = false;
		isJumped = false;
		moveVec = Vec2(0, 0);
	}
	void show_pack(Ref*pSender);
	void hide_pack(Ref* pSender);
	
	void update_of_obstruction(float time);//���ó����ֵĶ���
	bool is_hitted();//�ж����Ƿ񱻳�ײ
	virtual void update(float dt);
	void hitted_picture();//���˱���ײ�������ֵĻ���

	void to_theater(Ref* pSender);//ȥ��Ժ
	void to_right_street(Ref* pSender);
	void to_payboxScene(Ref*pSender);
	static bool is_look_tip;//ȷ��ÿ��ֻ�ܿ�һ����ʾ
	void timeOver();
	string getTheName();
	string getPassword();

protected:
	MenuItemImage *pack;//������ť
	Sprite* backpack;//��������
	Sprite* man;
	Sprite* move_car;//�ƶ��ĳ�
	Sprite* die_picture;//����ײ�Ժ���ֵ�ͼƬ
	Size size;
	File file;
	Sprite*background;
	CallbackTimeCounter* timecount;
	MenuItemImage* back_to_menu;
	MenuItemImage* tip;
	MenuItemImage* tryagain;
	MenuItemImage* back;
	MenuItemImage* right_street;//ȥ���ұߵĽֵ��İ�ť
	Calculagraph leftTime;
	LabelTTF* labelTime;

	bool isPressed;
	bool isJumped;
	Vec2 moveVec;
	float jumpVec;
	void onKeyPressed(EventKeyboard::KeyCode keyCode, Event *event);
	void onKeyReleased(EventKeyboard::KeyCode keycode, Event *event);

};
#endif
