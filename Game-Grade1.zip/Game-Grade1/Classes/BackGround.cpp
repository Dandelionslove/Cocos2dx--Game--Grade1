#include"BackGround.h"
#include"SimpleAudioEngine.h"
#include"MenuScene.h"

USING_NS_CC;
using namespace cocos2d;
using namespace CocosDenshion;

Scene* BackGround::createScene()
{
	auto scene = Scene::create();
	auto layer = BackGround::create();
	scene->addChild(layer);
	return scene;
}

bool BackGround::init()
{
	if (!Layer::init())
	{
		return false;
	}

	visibleSize = Director::getInstance()->getVisibleSize();
	SimpleAudioEngine::getInstance()->playBackgroundMusic("keyboard.wav");

	auto background = Sprite::create("beginBG.png");
	background->setPosition(Vec2(visibleSize.width/2,visibleSize.height/2));
	this->addChild(background,0);

	//������һ��һ�г���
	Vec2 origin = Director::getInstance()->getVisibleOrigin();
    text = CCLabelTTF::create("In 1991\n\na common night,\n\n a little boy named Shang Yu missed.\n\n Then,\n\n the murderer extorted to the boy\'s parents by telephone.\n\n Every time the phone rang\n\n would bring the boy\'s family more despair.\n\n When we are surrounded by evil,\n\n even\n\n we can\'t see his true face,\n\nthe sound of demons follows us as the shadow ,\n\nwhat should we do?\n\nGive up and compromise\n\n or \n\nsearch for the only light in the desperate.\n\n","UWJACK8",20);//��˫����������������޸ĵ�Ư��һЩ
	text->setPosition(ccp(300, -200));
	CCDrawNode* shap = CCDrawNode::create();
	CCPoint point[4] = { ccp(0,0),ccp(900,0),ccp(0,900),ccp(900,900) };
	shap->drawPolygon(point, 4, ccc4f(255, 255, 255, 255), 100, ccc4f(255, 255, 255, 255));
	CCClippingNode* cliper = CCClippingNode::create();
	cliper->setStencil(shap);
	cliper->setAnchorPoint(ccp(.5, .5));
	cliper->setPosition(ccp(100, 20));
	addChild(cliper);
	cliper->addChild(text);
	this->schedule(schedule_selector(BackGround::rollText));

	menuButton = MenuItemImage::create(
		"startgame_normal.png",
		"startgame_normal.png",
		CC_CALLBACK_1(BackGround::menuCloseCallback, this));
	auto menu = Menu::create(menuButton, NULL);
	menu->setPosition(Vec2(visibleSize.width/3*2.5,visibleSize.height/6));
	this->addChild(menu);

	//������ʱ��ʹ�������һ�е�����Ļ�м�ʱ�˵���ť�Ƶ���Ļ�м䲢��˸һ��֮��Ŵ�
	buttonMove = CallbackTimeCounter::create();
	this->addChild(buttonMove);
	buttonMove->start(39.0f, [=]() 
	{
		MoveTo* moveTo = MoveTo::create(0.9f, Vec2(-300,200));
		Blink* blink = Blink::create(1.0f, 1);
		ScaleTo* scaleTo = ScaleTo::create(2.0f, 2.0f, 0.9f);
		Action* actions = Sequence::create(moveTo, blink,scaleTo, NULL);
		menuButton->runAction(actions);
	});

	return true;
}

void BackGround::rollText(float)
{
		text->setPositionY(text->getPositionY()+0.5);
}

void BackGround::menuCloseCallback(Ref*pSender)
{
	Director::getInstance()->replaceScene(TransitionFade::create(0.5f, MenuScene::createScene()));
}