#include "funicularScene.h"
#include "SecondTollgate_2.h"
#include "File.h"
#include "downScene.h"
#include "CallbackTimeCounter.h"
Scene * downScene::createScene()
{
	auto scene = Scene::create();
	auto layer = downScene::create();
	scene->addChild(layer);
	return scene;
}

bool downScene::init()
{
	if (!Layer::init())
	{
		return false;
	}
	//����ͼƬ
	auto background = Sprite::create("secondScene.png");
	background->setPosition(Vec2(1050, 320));
	addChild(background);

	//�³�����
	auto funicularAndMan = Sprite::create("funicularAndMan.png");
	funicularAndMan->setPosition(Vec2(50,550));
	addChild(funicularAndMan);
	/////////////////////////////////////��ɽ·��////////////////////////////////////////
	MoveBy* moveBy5 = MoveBy::create(2, ccp(-200, 0));
	Action* actions1 = Sequence::create(moveBy5, NULL);
	background->runAction(actions1);

	// �����ƶ��������� 
	MoveBy* moveBy1 = MoveBy::create(2, ccp(0, -120));
	MoveBy* moveBy2 = MoveBy::create(2, ccp(290, -45));
	MoveBy* moveBy3 = MoveBy::create(2, ccp(260, -50));
	MoveBy* moveBy4 = MoveBy::create(2, ccp(255, -95));
	CCActionInterval * easeSineOut = CCEaseSineIn::create(moveBy1);
	CCActionInterval * easeSineIn = CCEaseSineOut::create(moveBy4);
	// ������϶������󣬽����ж��������� 
	Action* actions = Sequence::create(moveBy1, moveBy2, moveBy3, moveBy4, NULL);

	funicularAndMan->runAction(actions);

	this->scheduleUpdate();
	//������ʱ�����ж��Ƿ�ʱ���Ե�������
	auto timecount = CallbackTimeCounter::create();
	this->addChild(timecount);
	timecount->start(8.0f, [=]()
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SecondTollgate_2::createScene()));
	});

	return true;
}

void downScene::update(float delta)
{
	this->removeChild(downlabeltime);
	std::stringstream ss;
	std::string val;
	ss << int(leftTime.getTime() / 60);
	ss >> val;
	downlabeltime = LabelTTF::create(val, "Arial", 60);
	downlabeltime->setPosition(Vec2(600, 600));
	this->addChild(downlabeltime);

	if (leftTime.setTime(1.0f))
		return;
	else
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SecondTollgate_2::createScene()));
	}

}


