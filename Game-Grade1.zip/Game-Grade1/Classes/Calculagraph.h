///////////////////////////////////////////////////////
//ÿһ��ͨ�غ������	bool deletetimeFile();
//////////////////////////////////////////////////////
#ifndef __Calculagraph_H__
#define __Calculagraph_H__
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include <string>
using namespace cocostudio::timeline;
using namespace cocos2d;

class Calculagraph : public cocos2d::Layer
{
public:
	Calculagraph();
	~Calculagraph();
	bool setTime(int time);//����Ϊʱ��ļ���������λ����
	int getTime();
	bool deletetimeFile();

	bool init();

private:
};
#endif // !__Calculagraph_H__