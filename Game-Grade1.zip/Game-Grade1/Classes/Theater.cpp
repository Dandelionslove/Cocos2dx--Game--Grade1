#include"Theater.h"
#include"FirstTollgate_3.h"
#include"SimpleAudioEngine.h"
#include"CallbackTimeCounter.h"
#include"SecondTollgate_1.h"
#include <fstream>

USING_NS_CC;
using namespace CocosDenshion;

Scene * Theater::createScene()
{
	auto scene = Scene::create();
	auto layer = Theater::create();
	scene->addChild(layer, 1);
	return scene;
}

bool Theater::init()
{
	if (!Layer::init())
	{
		return false;
	}
	this->scheduleUpdate();
	size = Director::getInstance()->getVisibleSize();
	SimpleAudioEngine::getInstance()->playBackgroundMusic("Intro.mp3");//��˫�������ž�Ժ��������������޸�
	SimpleAudioEngine::getInstance()->setBackgroundMusicVolume(0.01);
	background = Sprite::create("theater_inner.png");//��˫����ͼ�д��޸�
	this->addChild(background);
	background->setPosition(size.width / 2, size.height / 2);

	room = MenuItemImage::create("room.png", "room.png", CC_CALLBACK_1(Theater::show_message, this));
	auto menu_1 = Menu::create(room, NULL);
	this->addChild(menu_1);
	menu_1->setPosition(850, 300);

	return true;
}

void Theater::update(float delta)
{
	this->removeChild(theaterlabeltime);
	std::stringstream ss;
	std::string val;
	ss << int(leftTime.getTime() / 60);
	ss >> val;
	theaterlabeltime = LabelTTF::create(val, "Arial", 60);
	theaterlabeltime->setPosition(Vec2(600, 600));
	this->addChild(theaterlabeltime);

	if (leftTime.setTime(1.0f))
		return;
	else
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, FirstTollgate_3::createScene()));
		return;
	}

}

void Theater::show_message(Ref * pSender)
{
	SimpleAudioEngine::getInstance()->stopBackgroundMusic();
	auto message = Sprite::create("film.png");//չʾ������Ϣ��ͼƬ
	this->addChild(message);
	File file(getTheName(), getPassword());
	file.firstSceneSuccess();
	message->setPosition(size.width / 2, size.height / 2);
	Blink* blink = Blink::create(1.0f, 3);
	message->runAction(blink);
	SimpleAudioEngine::getInstance()->playEffect("you are right.mp3");//��˫������������֮�����Ч���֣����ã�ע��ʱ��
	CallbackTimeCounter*win_music = CallbackTimeCounter::create();
	this->addChild(win_music);
	//win_music->start(3.0f, [=]()
	//{
	//	SimpleAudioEngine::getInstance()->playEffect("you are right.mp3");//��˫�����˴������д��Ľ�
	//});
	//����������һ�صĻ���
	CallbackTimeCounter*show_win = CallbackTimeCounter::create();
	this->addChild(show_win);
	show_win->start(2.0f, [=]() 
	{
		auto win_words =CCLabelTTF::create("Congratuations!\nYou find one clue!\n", "Arial", 30);
		this->addChild(win_words);
		win_words->setPosition(size.width / 2, size.height / 2+100);
		auto light = Blink::create(1.0f, 1);//������һ��
		win_words->runAction(light);
		CallbackTimeCounter*next_tollgate = CallbackTimeCounter::create();
		this->addChild(next_tollgate);
		next_tollgate->start(1.5f, [=]() 
		{
			Calculagraph time;
			time.setTime(-7200+time.getTime());
			SimpleAudioEngine::getInstance()->stopAllEffects();
			Director::getInstance()->replaceScene(SecondTollgate_1::createScene());//��˫���������л�Ч�����޸�
		});
	});

}


string Theater::getTheName()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	tempfile >> temp;
	tempfile.close();

	return temp;
}

string Theater::getPassword()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp1;
	string temp;
	tempfile >> temp1;
	tempfile >> temp;
	tempfile.close();
	return temp;
}
