#ifndef _MenuScene_H_
#define _MenuScene_H_

#include"cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

using namespace cocos2d;
using namespace std;

class MenuScene :public Layer
{
public:
	CREATE_FUNC(MenuScene);

	static Scene* createScene();
	virtual bool init();
	void to_firsttollgate(Ref* pSender);
	void to_requirement(Ref* pSender);
	void to_tollgates(Ref* pSender);
	string getTheName();
	string getPassword();
};

#endif