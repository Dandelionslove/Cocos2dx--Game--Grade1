#ifndef _Requirement_H_
#define _Requirement_H_

#include"cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

using namespace cocos2d;

class Requirement:public Layer
{
public:
	static Scene* createScene();
	virtual bool init();
	void menuCloseCallback(Ref* pSender);

	CREATE_FUNC(Requirement);
};
#endif