#include "File.h"
#include <cstdlib>
#include <fstream>

using namespace std;
USING_NS_CC;

File::File(string name, string password)
{
	ifstream rdatafile;
	_name = name + ".txt";
	_password = password;
	rdatafile.open(_name, ios::in);
	if (!(rdatafile.is_open()))
	{
		ofstream wdatafile;
		wdatafile.open(_name);
		wdatafile << "money 03000" << endl;
		wdatafile << "password " << _password << endl;
		wdatafile << "heart 5" << endl;
		wdatafile << "telescope 0" << endl;
		wdatafile << "ticket 0" << endl;
		wdatafile << "umbrella 0" << endl;
		wdatafile << "newspaper 0" << endl;
		wdatafile << "firstScene 0" << endl;
		wdatafile << "secondScene 0" << endl;
		wdatafile << "thirdScene 0" << endl;
		wdatafile << "getSecondSceneTip 0" << endl;
		wdatafile.close();
	}
	rdatafile.close();
}

int File::read(string str)
{
	ifstream file;
	file.open(_name);
	if (!file)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	int num;
	while (file.good())
	{
		file >> temp;
		if (temp == str)
		{
			file >> num;
			file.close();
			return num;
		}
	}
	return 0;
}

void File::write(string str, int value)
{
	fstream file;
	file.open(_name, ios_base::in | ios_base::out | ios_base::binary);
	file.seekg(0);
	if (!file.is_open())
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	else
	{
		file.seekg(0);
		if (str == "money")
		{
			std::stringstream ss;
			std::string val;
			ss << value;
			ss >> val;
			int len = 5 - val.length();
			for (int i = 0; i <len; i++)
			{
				val = "0" + val;
			}
			string temp;
			file >> temp;
			file.seekg(sizeof(char), ios::cur);
			file << val;
			return;
		}
		string temp[22];
		int i = 0;
		while (file.good())
		{
			file >> temp[i];
			if (temp[i] == str)
			{
				file.seekg(sizeof(char), ios::cur);
				file << value;
				file.close();
				return;
			}
			i++;
		}
	}
}


File::~File() {}

int File::checkPassword(string text)
{
	ifstream file;
	file.open(_name);
	if (!file)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	while (file.good())
	{
		file >> temp;
		if (temp == "password")
		{
			file >> temp;
			file.close();
			if (temp == text)
				return 1;
			else
				return 0;
		}
	}
	return 0;

}

void File::clearData()
{
	ofstream wdatafile;

	wdatafile.open(_name);
	wdatafile << "money 03000" << endl;
	wdatafile << "password " << _password << endl;
	wdatafile << "heart 5" << endl;
	wdatafile << "telescope 0" << endl;
	wdatafile << "ticket 0" << endl;
	wdatafile << "umbrella 0" << endl;
	wdatafile << "newspaper 0" << endl;
	wdatafile << "firstScene 0" << endl;
	wdatafile << "secondScene 0" << endl;
	wdatafile << "thirdScene 0" << endl;
	wdatafile << "getSecondSceneTip 0" << endl;
	wdatafile.close();

}

void File::moneyIncrease(int inc)
{
	if ((read("money") - inc) >32767)
	{
		log("can not be negative\n");
		exit(EXIT_FAILURE);
	}

	write("money", read("money") + inc);
}

void File::moneyDecrease(int dec)
{
	if ((read("money") - dec) < 0)
	{
		log("can not be negative\n");
		exit(EXIT_FAILURE);
	}
	write("money", read("money") - dec);
}

int File::looseHeart()
{
	if (read("heart") > 1)
	{
		write("heart", read("heart") - 1);
		return 1;
	}
	return 0;
}

int File::checkHeart()
{
	return read("heart");
}

int File::getMoney()
{
	return read("money");
}

int File::checkTicket()
{
	return read("ticket");
}

void File::buyTicket()
{
	write("ticket", 1);
}

void File::useTicket()
{
	write("ticket", 0);
}

void File::buyTelescope()
{
	write("telescope", 1);
}

int File::checkTelescope()
{
	return read("telescope");
}

void File::buyUmbrella()
{
	write("umbrella", 1);
}

int File::checkUmbrella()
{
	if (read("umbrella"))
		return true;
	return false;
}

void File::buyNewspaper()
{
	write("newspaper", 1);
}

int File::checkNewspaper()
{
	return read("newspaper");
}

void File::firstSceneSuccess()
{
	write("firstScene", 1);
}

int File::isFirstSceneSuccess()
{
	if (read("firstScene"))
	{
		return true;
	}
	return false;
}

void File::secondSceneSuccess()
{
	write("secondScene", 1);
}

void File::getSecondSceneTip(int is)
{
	write("getSecondSceneTip", is);
}

int File::getSecondSceneTip()
{
	return read("getSecondSceneTip");
}

int File::isSecondSceneSuccess()
{
	if (read("secondScene"))
	{
		return true;
	}
	return false;
}


void File::thirdSceneSuccess()
{
	write("thirdScene", 1);
}

int File::isThirdSceneSuccess()
{
	if (read("thirdScene"))
	{
		return true;
	}
	return false;
}


int File::isSuccess()
{
	if (read("firstScene") == 1 && read("secondScene") == 1 && read("thirdScene") == 1)
		return 1;
	else
		return 0;
}

