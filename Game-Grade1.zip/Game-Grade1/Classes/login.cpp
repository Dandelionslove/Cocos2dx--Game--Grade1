#include "login.h"
#include "file.h"
#include <fstream>
#include "BeginningScene.h"
#include "CallbackTimeCounter.h"
USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d;
using namespace cocos2d::ui;

Scene*  Login::createScene()
{
	auto scene = Scene::create();
	auto layer = Login::create();
	scene->addChild(layer);
	return scene;
}

bool Login::init()
{
	if (!Layer::init())
	{
		return false;
	}
	auto exchage_bg = Sprite::create("loginscene.png");
	exchage_bg->setPosition(Vec2(380, 300));
	addChild(exchage_bg);

	auto inputBox = Sprite::create("loginInput.png");
	inputBox->setPosition(Vec2(400, 300));
	addChild(inputBox);
	auto editBox = EditBox::create(Size(inputBox->getContentSize().width, inputBox->getContentSize().height), Scale9Sprite::create("exchage_input_frame.png"));
	editBox->setPosition(Vec2(440, 300));
	editBox->setMaxLength(10);   //����������������ٸ��ַ�
	editBox->setText("Please input your name:"); //��ʼ������
	editBox->setFontColor(Color3B(255, 255, 255));   //������ɫ
	editBox->setFontSize(20);   
	addChild(editBox);

	auto inputBox2 = Sprite::create("loginInput.png");
	inputBox2->setPosition(Vec2(430, 230));
	addChild(inputBox2);

	auto editBox2 = EditBox::create(Size(inputBox2->getContentSize().width, inputBox2->getContentSize().height), Scale9Sprite::create("exchage_input_frame.png"));
	editBox2->setPosition(Vec2(430, 230));
	editBox2->setMaxLength(10);  
	editBox2->setText("Please input your password:");
	editBox2->setFontColor(Color3B(255, 255, 255));  
	editBox2->setFontSize(20);  
	addChild(editBox2);

	//���밴ť
	auto Exchangebuttom = MenuItemImage::create("enter.png", "enter.png");
	Exchangebuttom->setPosition(Vec2(400, 150));
	Exchangebuttom->setCallback([&, editBox, editBox2](Ref*obj) {
		//ȡ����������������
		name = editBox->getText();
		password = editBox2->getText();
		OkButton();
	});

	auto menu = Menu::create(Exchangebuttom, NULL);
	menu->setPosition(Point::ZERO);
	exchage_bg->addChild(menu);
	this->m_size = Director::sharedDirector()->getVisibleSize();
}

void Login::OkButton()
{
	ofstream tempfile;
	tempfile.open("tempfile.txt");
	if (name == "Please input your name:")
	{
		auto timecount = CallbackTimeCounter::create();
		this->addChild(timecount);
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("Please input your name.", "Arial", 60);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);

		timecount->start(2.0f, [=]() 
		{
			Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, Login::createScene()));
		});

	}
	else
	{
		ifstream rdatafile;
		rdatafile.open(name + ".txt", ios::in);
		if (rdatafile.is_open())
		{
			File file(name, password);
			if (file.checkPassword(password))
			{
				tempfile << name << " ";
				tempfile << password;
				Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, BeginningScene::createScene()));
			}
			else
			{
				auto timecount = CallbackTimeCounter::create();
				this->addChild(timecount);
				Size size = Director::getInstance()->getVisibleSize();
				LabelTTF* tip = LabelTTF::create("Your password is wrong.\n ", "Arial", 60);
				tip->setPosition(size.width / 2, size.height / 2);
				this->addChild(tip);

				timecount->start(2.0f, [=]()
				{
					Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, Login::createScene()));

				});

			}
		}
		else
		{
			tempfile << name << " ";
			tempfile << password;

			File(name, password);
			Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, BeginningScene::createScene()));

		}

	}
}