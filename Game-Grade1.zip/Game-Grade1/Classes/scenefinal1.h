#ifndef __THREE_SCENEF1_H__
#define __THREE_SCENEF1_H__
#include<iostream>
#include "cocos2d.h"
#include "TimeCounter.h"
#include"CallbackTimeCounter.h"
using namespace cocos2d;

class SCENEF1 :public cocos2d::Layer
{
public:
	virtual bool init();
	static  cocos2d::Scene* scene();
	void to_menu(Ref* pSender);
	CREATE_FUNC(SCENEF1);
private:
	TimeCounter* m_timeCounter;
	Sprite *father;
	Sprite *son;
	MenuItemImage* playagain;
};
#endif

