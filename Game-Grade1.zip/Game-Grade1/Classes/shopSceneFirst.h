#ifndef __shopSceneFirst_H__
#define __shopSceneFirst_H__
#include"cocos2d.h"
#include"CallbackTimeCounter.h"
#include "Calculagraph.h"
#include<map>
using namespace std;
using namespace cocos2d;

class shopSceneFirst :public Layer
{
public:
	static Scene* createScene();
	virtual bool init();
	void buyTelescope(Ref*pSender);
	void buyUmbrella(Ref*pSender);
	void returnshopSceneFirst(Ref* pSender);
	void okBuyTelescope(Ref * pSender);
	void okBuyUmbrella(Ref * pSender);
	void returnFirstScene(Ref * pSender);
	void show_pack(Ref*pSender);
	void hide_pack(Ref* pSender);
	string getTheName();
	string getPassword();

	void update(float delta)override;

	CREATE_FUNC(shopSceneFirst);
protected:
	Menu* menu;
	Calculagraph leftTime;
	Sprite* man;
	map<EventKeyboard::KeyCode, bool>keys;

	Calculagraph shoptime;
	LabelTTF*  shoplabeltime;
	MenuItemImage *pack;//������ť
	Sprite* backpack;//��������


};

#endif 
