#include"SecondTollgate_2.h"
#include"SimpleAudioEngine.h"
#include"scene31.h"
#include "MenuScene.h"
#include "TimeCounter.h"
#include "Calculagraph.h"
#include "CallbackTimeCounter.h"
#include"cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"useTicketScene.h"
#include "shopScene.h"
#include "payboxScene.h"
#include <fstream>
USING_NS_CC;
using namespace CocosDenshion;
using namespace std;

SecondTollgate_2::SecondTollgate_2() :is_look_tip(false), is_big_roll(false), is_small_roll(false), file(getTheName(), getPassword())
{
}
string SecondTollgate_2::getTheName()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	tempfile >> temp;
	tempfile.close();

	return temp;
}

string SecondTollgate_2::getPassword()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp1;
	string temp;
	tempfile >> temp1;
	tempfile >> temp;
	tempfile.close();
	return temp;
}

SecondTollgate_2::~SecondTollgate_2()
{
}

Scene* SecondTollgate_2::createScene()
{
	auto scene = Scene::create();
	auto layer = SecondTollgate_2::create();
	scene->addChild(layer, 1);
	return scene;
}

bool SecondTollgate_2::init()
{
	if (!Layer::init())
	{
		return false;
	}

	Size size = Director::getInstance()->getVisibleSize();

	SimpleAudioEngine::getInstance()->playBackgroundMusic("intro.mp3", true);

	auto background = Sprite::create("secondScene.png");
	background->setPosition(Vec2(200, 320));
	addChild(background);

	//��Ʊ��
	auto button21 = MenuItemImage::create(
		"paybox.png",
		"paybox.png",
		CC_CALLBACK_1(SecondTollgate_2::paybox_scene, this));
	auto menu_1 = Menu::create(button21, NULL);
	menu_1->setPosition(Vec2(500, 150));
	this->addChild(menu_1);

	//�̵�
	auto button22 = MenuItemImage::create(
		"shop.png",
		"shop.png",
		CC_CALLBACK_1(SecondTollgate_2::shopScene, this));
	auto menu_2 = Menu::create(button22, NULL);
	menu_2->setPosition(Vec2(800, 150));
	this->addChild(menu_2);

	//�³�
	auto funicular = Sprite::create("funicular.png");
	funicular->setPosition(Vec2(150, 300));
	addChild(funicular);

	//����1

	auto jinggai = Sprite::create("manhole_cover.png");
	jinggai->setPosition(Vec2(800, 120));
	addChild(jinggai);
	
	//����2

	auto jinggai2 = Sprite::create("manhole_cover.png");
	jinggai2->setPosition(Vec2(360, 120));
	addChild(jinggai2);

		//������Ա
		auto personnel = MenuItemImage::create(
		"worker2.png",  //wait!!!!!
		"worker2.png",
		CC_CALLBACK_1(SecondTollgate_2::useTicketScene, this));
		auto menu_3 = Menu::create(personnel, NULL);
		menu_3->setPosition(Vec2(300, 130));
		this->addChild(menu_3);

		/*///�������˶���
    
		

		int num = 4;
		int num2 = 200;
		CCAnimation *animation_1 = CCAnimation::create();
		for (int j = 1; j <= 200; j++)
		{
			for (int i = 1; i <= 4; ++i)
			{
				char pName[30] = { 0 };
				sprintf(pName, "man_%d.png", i);
				animation_1->addSpriteFrameWithFileName(pName);
			}
		}
		animation_1->setDelayPerUnit(1.0f / 10.0f);
		animation_1->setRestoreOriginalFrame(true);
		CCAnimate *action = CCAnimate::create(animation_1);
		CCSprite *sprite = CCSprite::create("man_1.png");
		sprite->setAnchorPoint(Vec2(1.0f, 1.0f));
		sprite->setPosition(Vec2(500, 500));
		this->addChild(sprite, 2);

		CCSprite sprite= *animation_1;*/

	//������
	this->man = Sprite::create("man.png");
	man->setPosition(Vec2(650, 130));
	this->addChild(man);
		/*	CCSize s = CCDirector::sharedDirector()->getWinSize();  //��ȡ�����С
		CCArray *aniframe = CCArray::createWithCapacity(4);   //��������Ϊ4�ļ���
		CCSprite *sprite;//����
		char str[20];
		for (int i = 0; i<4; i++) {

			sprintf(str, "attack/man_%d.png", i);  //ͨ���±궯̬��������
			CCSpriteFrame *frame = CCSpriteFrame::create(str, CCRectMake(0, 0, 64, 64));
			if (i == 0) {//Ĭ�����ӵ�һ֡ͼ��������
				sprite = CCSprite::createWithSpriteFrame(frame);
				sprite->setPosition(ccp(650,130));
				addChild(sprite);
			}
			aniframe->addObject(frame);//��ÿһ֡���鶯�����ӵ���������
		}

		CCAnimation *animation = CCAnimation::createWithSpriteFrames(aniframe, 0.2f);//ͨ�����ϴ�������
		CCAnimate *animate = CCAnimate::create(animation);
		CCActionInterval* seq = (CCActionInterval*)(CCSequence::create(animate,
			CCFlipX::create(true),
			animate->copy()->autorelease(),
			CCFlipX::create(false),
			NULL
			));

		sprite->runAction(CCRepeatForever::create(seq));//ִ�ж���

	
	*/
//	_eventDispatcher->addEventListenerWithSceneGraphPriority(move, this);
	//�����˵���ť
	back_to_menu = MenuItemImage::create("back_menu.png", "back_menu.png", CC_CALLBACK_1(SecondTollgate_2::to_menu, this));
	tip = MenuItemImage::create("tip.png", "tip.png", CC_CALLBACK_1(SecondTollgate_2::show_tip, this));
	 menu = Menu::create(tip, back_to_menu, NULL);
	this->addChild(menu, 5);
	menu->alignItemsVerticallyWithPadding(20);
	menu->setPosition(Vec2(50, 100));

	//����һ��������ť
	pack = MenuItemImage::create("pack_button.png", "pack_button.png", CC_CALLBACK_1(SecondTollgate_2::show_pack, this));
	auto menu_5 = Menu::create(pack, NULL);
	this->addChild(menu_5, 5);
	menu_5->setPosition(50, 220);
	this->scheduleUpdate();

	//����̲����й�
	auto keyBoardListener = EventListenerKeyboard::create();
	keyBoardListener->onKeyPressed = CC_CALLBACK_2(SecondTollgate_2::onKeyPressed, this);
	keyBoardListener->onKeyReleased = CC_CALLBACK_2(SecondTollgate_2::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(keyBoardListener, man);
	
	//ʯͷ����
	this->schedule(schedule_selector(SecondTollgate_2::update_of_stone), 5.0f);
	this->schedule(schedule_selector(SecondTollgate_2::update_of_judge_position), 1.0 / 60);

	return true;
}

void SecondTollgate_2::next_scene(Ref* pSender)
{
	Scene*scene = SCENE31::createScene();
	Director::sharedDirector()->replaceScene(scene);
	leftTime.deletetimeFile();

}

void SecondTollgate_2::paybox_scene(Ref * pSender)
{
	Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f,  payboxScene::createScene()));

}

void SecondTollgate_2::useTicketScene(Ref * pSender)
{
	Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f, useTicketScene::createScene()));
}

void SecondTollgate_2::try_again(Ref* pSender)
{
	leftTime.setTime(-7200 + leftTime.getTime());
	file.looseHeart();

	if (file.checkHeart() > 1)
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SecondTollgate_2::createScene()));
	}
	else
	{
		file.clearData();
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, MenuScene::createScene()));
	}

}

void SecondTollgate_2::to_menu(Ref* pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, MenuScene::createScene()));
}

void SecondTollgate_2::shopScene(Ref * pSender)
{
	Director::getInstance()->pushScene(TransitionCrossFade::create(0.0f, shopScene::createScene()));

}

void SecondTollgate_2::update(float delta)
{
	if ((man->getPositionX() > 548
		&& man->getPositionX() < 552
		&& man->getPositionY()> 120
		&& man->getPositionY() < 140)||
		(man->getPositionX() > 848
			&& man->getPositionX() < 852
			&& man->getPositionY()> 120
			&& man->getPositionY() < 140))
	{
		this->dropInto();
	}

	this->removeChild(labelTime);
	std::stringstream ss;
	std::string val;
	ss <<  int(leftTime.getTime()/60);
	ss >> val;
	labelTime = LabelTTF::create(val, "UWJACK8", 60);
	labelTime->setPosition(Vec2(600,600));
	this->addChild(labelTime);

	if (leftTime.setTime(1.0f))
		return;
	else
	{
		timeOver();
		return;
	}
}

void SecondTollgate_2::dropInto()
{
	CCActionInterval * moveBy = CCMoveBy::create(2, ccp(0, 120));
	CCActionInterval * actionmoveback= moveBy->reverse();
	man->runAction(actionmoveback);
	auto timecount = CallbackTimeCounter::create();
	this->addChild(timecount);
	timecount->start(3.0f, [=]()
	{
		File file(getTheName(), getPassword());

		Size size = Director::getInstance()->getVisibleSize();
		die_picture = Sprite::create("die_picture.png");//��˫����ͼƬ��ģ��˴���Ϊ��ʯͷ�����Ļ���
		this->addChild(die_picture, 200);
		die_picture->setPosition(Vec2(470, 320));

		
		MenuItemImage* tryagain = MenuItemImage::create("tryAgain.png", "tryAgain.png", CC_CALLBACK_1(SecondTollgate_2::try_again, this));
		MenuItemImage* back = MenuItemImage::create("menu.png", "menu.png", CC_CALLBACK_1(SecondTollgate_2::to_menu, this));
		auto menu_2 = Menu::create(tryagain, back, NULL);
		die_picture->addChild(menu_2,290);
		menu_2->setPosition(Vec2(470, 170));
		menu_2->alignItemsVerticallyWithPadding(10);

	});

}


void SecondTollgate_2::timeOver()
{
	Size size = Director::getInstance()->getVisibleSize();
	LabelTTF* lose = LabelTTF::create("You are losing!", "UWJACK8", 40);
	lose->setPosition(size.width / 2, size.height / 2+150);
	this->addChild(lose);

	auto try_againScene = Sprite::create("try_againScene.png");
	try_againScene->setPosition(Vec2(470, 320));
	addChild(try_againScene,100);

	MenuItemImage* tryagain = MenuItemImage::create("tryAgain.png", "tryAgain.png", CC_CALLBACK_1(SecondTollgate_2::try_again, this));
	MenuItemImage* back = MenuItemImage::create("menu.png", "menu.png", CC_CALLBACK_1(SecondTollgate_2::to_menu, this));
	auto menu_2 = Menu::create(tryagain, back, NULL);
	this->addChild(menu_2);
	menu_2->alignItemsVerticallyWithPadding(10);
}

void SecondTollgate_2::show_tip(Ref* pSender)
{
	Size _size = Director::getInstance()->getVisibleSize();
	if (is_look_tip)
	{
		return;
	}
	this->is_look_tip = true;
	auto tip = Sprite::create("tiptext_2.png");//��˫������ʾ
	this->addChild(tip,10);
	tip->setPosition(_size.width / 2, _size.height - 100);
	CallbackTimeCounter* _tip = CallbackTimeCounter::create();
	this->addChild(_tip);
	_tip->start(5.0f, [=]()
	{
		this->removeChild(tip);
	});
}

void SecondTollgate_2::show_pack(Ref * pSender)
{
	backpack = Sprite::create("backpack.png");
	this->addChild(backpack);
	backpack->setPosition(size.width / 2, size.height / 2);
	auto pack_menu = Menu::create();
	backpack->addChild(pack_menu);
	pack_menu->setPosition(size.width / 2, size.height / 2);
	//�����ֵı���////////////////��˫�����ȴ��������ж�����ͼƬ��������ע��������ʹ�ð�ť����������Ϊ0����ʹ�ð�ť����////////////////////////////
	//////////////////////////////////��˫�����Ժ��ÿһ���ؿ������ϱ���////////////////////////////////////////////////
	////��˫��������֤
	//auto IDcard = ::create("IDcard2.png");
	//backpack->addChild(IDcard, 1);
	//IDcard->setPosition(150, 350);
	////��˫����Ǯ��
	//Value _money = Value(file.getMoney());
	//Value v = Value("Money Number: ");
	//string num = v.asString() + _money.asString();
	//auto money_num = CCLabelTTF::create(num, "Arial", 20);
	//backpack->addChild(money_num, 10);
	//money_num->setPosition(150, 300);
	//money_num->setColor(Color3B(0, 0, 0));//��˫�������õ�������ɫ���ɸ�

	//											//��˫��������������������
	//auto things_name = Sprite::create("things_name.png");
	//auto number = Sprite::create("number.png");
	//backpack->addChild(things_name);
	//backpack->addChild(number);
	//things_name->setPosition(150, 400);
	//number->setPosition(450, 400);

	////��˫����Ʊ
	//auto ticket = Sprite::create("ticket.png");
	//backpack->addChild(ticket, 1);
	//ticket->setPosition(150, 250);
	//Value num_1 = Value(file.checkTicket());
	//auto ticket_num = CCLabelTTF::create(num_1.asString(), "Arial", 20);
	//ticket->addChild(ticket_num);
	//ticket_num->setPosition(400, 250);
	//ticket_num->setColor(Color3B(0, 0, 0));
	////��˫�����ֻ�
	//auto phone = Sprite::create("phone.png");
	//backpack->addChild(phone, 1);
	//phone->setPosition(150, 180);
	//phone->setScale(0.3f);
	//auto phone_num = CCLabelTTF::create("1", "Arial", 20);
	//phone->addChild(phone_num);
	//phone_num->setPosition(500, 175);
	//phone_num->setScale(5);
	//phone_num->setColor(Color3B(0, 0, 0));
	//// ��˫������ֽ
	//auto newspaper = Sprite::create("newspaper.png");
	//backpack->addChild(newspaper);
	//newspaper->setPosition(150, 140);
	//Value num_2 = Value(file.checkNewspaper());
	//auto newspaper_num = CCLabelTTF::create(num_2.asString(), "Arial", 20);
	//newspaper->addChild(newspaper_num);
	//newspaper_num->setColor(Color3B(0, 0, 0));
	//newspaper_num->setPosition(420, 140);
	////��˫������Զ��
	//auto telescope = Sprite::create("telescope.png");
	//backpack->addChild(telescope);
	//telescope->setPosition(150, 100);
	//Value num_3 = Value(file.checkTelescope());
	//auto telescope_num = CCLabelTTF::create(num_3.asString(), "Arial", 20);
	//telescope->addChild(telescope_num);
	//telescope_num->setColor(Color3B(0, 0, 0));
	//telescope_num->setPosition(450, 100);
	////��˫������ɡ
	//auto umbrella = Sprite::create("umbrella3.png");
	//backpack->addChild(umbrella);
	//umbrella->setPosition(130, 60);
	//Value num_4 = Value(file.checkUmbrella());
	//auto umbrella_num = CCLabelTTF::create(num_3.asString(), "Arial", 20);
	//umbrella->addChild(umbrella_num);
	//umbrella_num->setColor(Color3B(0, 0, 0));
	//umbrella_num->setPosition(130, 60);

	//��������
	Value de = Value("\n");
	Value d_1 = Value("IDcard: Father ");
	Value d_2 = Value("Life Number: "); Value v_2 = Value(file.checkHeart());
	Value d_3 = Value("Money: "); Value v_3 = Value(file.getMoney());
	Value d_4 = Value("Telescope: "); Value v_4 = Value(file.checkTelescope());
	Value d_5 = Value("Ticket: "); Value v_5 = Value(file.checkTicket());
	Value d_6 = Value("Umbrella: "); Value v_6 = Value(file.checkUmbrella());
	Value d_7 = Value("Newspaper: "); Value v_7 = Value(file.checkNewspaper());
	string  pack_content = d_1.asString() + de.asString() + d_2.asString() + v_2.asString() + de.asString() + d_3.asString() + v_3.asString() + de.asString() + d_4.asString() + v_4.asString() + de.asString() + d_5.asString() + v_5.asString() + de.asString() + d_6.asString() + v_6.asString() + de.asString() + d_7.asString() + v_7.asString() + de.asString();
	auto _pack_content = CCLabelTTF::create(pack_content, "UWJACK8", 40);
	backpack->addChild(_pack_content, 5);
	_pack_content->setPosition(350, 200);
	/*Value life= Value(file.checkHeart());
	Value d = Value("Life Number: ");

	string  life_num = d.asString() + life.asString();
	auto _life_num = CCLabelTTF::create(life_num, "Arial", 20);
	backpack->addChild(_life_num,15);
	_life_num->setColor(Color3B(0, 0, 0));
	_life_num->setPosition(120, 200);*/

	////��˫����������Ϸ����İ�ť
	auto back_scene = MenuItemImage::create("back_scene.png", "back_scene.png", CC_CALLBACK_1(SecondTollgate_2::hide_pack, this));
	auto back_scene_button = Menu::create(back_scene, NULL);
	backpack->addChild(back_scene_button);
	back_scene_button->setPosition(400, 30);


}

void SecondTollgate_2::hide_pack(Ref * pSender)
{
	this->removeChild(backpack);
}

void SecondTollgate_2::onKeyPressed(EventKeyboard::KeyCode keyCode, Event *event)
{
	isPressed = true;
	switch (keyCode) {
	case EventKeyboard::KeyCode::KEY_A:
	case EventKeyboard::KeyCode::KEY_CAPITAL_A:
	case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
	{
		if (man->getPositionX()>300)
			moveVec = Vec2(-30, 0);//��˫������ʱ�����update�������޸�
	}
	break;
	case EventKeyboard::KeyCode::KEY_D:
	case EventKeyboard::KeyCode::KEY_CAPITAL_D:
	case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
	{
		if (man->getPositionX()<930)
			moveVec = Vec2(30, 0);//��˫������ʱ�����update�������޸�
	}
	break;
	case EventKeyboard::KeyCode::KEY_W:
	case EventKeyboard::KeyCode::KEY_CAPITAL_W:
	case EventKeyboard::KeyCode::KEY_UP_ARROW:
		if (!isJumped&&man->getPositionY() < 200)
		{
			jumpVec = 80.0;
			isJumped = true;
			auto jump = JumpBy::create(1.0f, Vec2(0, 0), jumpVec, 1);
			auto callFunc = CallFunc::create([=]() {
				isJumped = false;
			});
			man->runAction(Sequence::create(jump, callFunc, NULL));
		}	break;
	default:
		break;
	}
	man->runAction(MoveBy::create(0.2, moveVec));

	return;
}

void SecondTollgate_2::onKeyReleased(EventKeyboard::KeyCode keycode, Event * event)
{
	isPressed = false;
	isJumped = false;
	moveVec = Vec2(0, 0);
	jumpVec = 0.0;
}

void SecondTollgate_2::update_of_stone(float time)
{
	if (!is_big_roll)
	{
		is_big_roll = true;
		big_stone = Sprite::create("big_stone.png");
		this->addChild(big_stone);
		big_stone->setPosition(-50, 300);
		auto roll_1 = MoveTo::create(4.0f, Vec2(240, 142));
		auto roll_2 = MoveTo::create(10.0f, Vec2(1100, 142));//��˫��������λ�����
		big_stone->runAction(Sequence::create(roll_1, roll_2, NULL));

		auto timecount = CallbackTimeCounter::create();
		this->addChild(timecount);
		timecount->start(10.0f, [=]()
		{
			is_small_roll = false;
		});
	}
	else if (!is_small_roll)
	{
		is_small_roll = true;
		small_stone = Sprite::create("small_stone.png");
		this->addChild(small_stone);
		small_stone->setPosition(-40, 250);
		auto roll_1 = MoveTo::create(4.0f, Vec2(120, 120));
		auto roll_2 = MoveTo::create(10.0f, Vec2(1100, 120));
		small_stone->runAction(Sequence::create(roll_1, roll_2, NULL));
		auto timecount = CallbackTimeCounter::create();
		this->addChild(timecount);
		timecount->start(10.0f, [=]()
		{
			is_big_roll = false;
		});

	}

}

bool SecondTollgate_2::is_hitted()
{
	if (is_big_roll&&big_stone)
	{
		float x1 = big_stone->getPositionX(),
			x2 = man->getPositionX(),
			y1 = big_stone->getPositionY(),
			y2 = man->getPositionY();
		if (fabs(x1 - x2) < 60)
		{
			if (fabs(y1 - y2) < 40)//�ж����Ƿ񱻴�ʯͷײ�� ��˫�������ִ���
				return true;
		}
	}
	
	if (is_small_roll&&small_stone)
	{
		float x3 = small_stone->getPositionX(), 
			x4 = man->getPositionX(), 
			y3 = small_stone->getPositionY(), 
			y4 = man->getPositionY();
		if (fabs(x3 - x4) < 40)
		{
			if (fabs(y3 - y4) < 30)//�ж����Ƿ�Сʯͷײ�� ��˫�������ִ���
				return true;
		}
	}
	return false;
}

void SecondTollgate_2::update_of_judge_position(float time)
{
	if (is_hitted())
	{
		this->show_hitted_pictrue();
		man->setOpacity(0);
	}
}

//��˫����������������
void SecondTollgate_2::show_hitted_pictrue()
{
	Size visiblesize = Director::getInstance()->getVisibleSize();
	this->setSwallowsTouches(true);
	die_picture = Sprite::create("die_picture.png");//��˫����ͼƬ��ģ��˴���Ϊ��ʯͷ�����Ļ���
	this->addChild(die_picture, 100);
	die_picture->setPosition(visiblesize.width / 2, visiblesize.height / 2);
	die_tryagain = MenuItemImage::create("try again.png", "try again.png", CC_CALLBACK_1(SecondTollgate_2::try_again, this));
	die_back = MenuItemImage::create("back_menu.png", "back_menu.png", CC_CALLBACK_1(SecondTollgate_2::to_menu, this));
	auto die_menu = Menu::create(die_tryagain, die_back, NULL);
	die_picture->addChild(die_menu,90);
	die_menu->setPosition(460, 170);
	die_menu->alignItemsVerticallyWithPadding(5);
}
