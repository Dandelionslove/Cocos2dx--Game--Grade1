#include"scene32.h"
#include"scene33success.h"
#include"scenefinal1.h"
#include"FirstTollgate_1.h"
#include"MenuScene.h"
#include <fstream>
#include"SimpleAudioEngine.h"
using namespace CocosDenshion;

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d;
using namespace cocos2d::ui;

Scene*SCENE32::scene()
{
	Scene*scene = Scene::create();
	SCENE32*layer = SCENE32::create();
	scene->addChild(layer);
	return scene;
}

bool SCENE32::init()
{
	if (!Layer::init())
	{
		return false;
	}
	tryTime = 3;

	Size size = Director::sharedDirector()->getWinSize();
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Point origin = Director::getInstance()->getVisibleOrigin();
	SimpleAudioEngine::getInstance()->playBackgroundMusic("Puzzle.mp3", true);

	bg2 = Sprite::create("daytime.png");
	bg2->setPosition(Vec2(0, 320));
	this->addChild(bg2);
	
	sprite1= Sprite::create("man.png");//�ְ�ͼƬ
	this->addChild(sprite1);
	sprite1->setPosition(Vec2(480, 160));
	auto keyBoardListener = EventListenerKeyboard::create();
	keyBoardListener->onKeyPressed = CC_CALLBACK_2(SCENE32::onKeyPressed, this);
	keyBoardListener->onKeyReleased = CC_CALLBACK_2(SCENE32::onKeyReleased, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(keyBoardListener, sprite1);
	this->scheduleUpdate();

	//ATM��
	auto ATM = MenuItemImage::create(
		"ATM.png",
		"ATM.png",
		CC_CALLBACK_1(SCENE32::onMenuButton, this));
	Menu*menu = Menu::create(ATM, NULL);
	menu->setPosition(Point(1100, 250));
	bg2->addChild(menu, 0);

	auto waimai = MenuItemImage::create(
		"waimai.png",
		"waimai.png",
		CC_CALLBACK_1(SCENE32::onAddItem1, this));
	Menu*menu1 = Menu::create(waimai, NULL);
	menu1->setPosition(Point(1530,200));
	bg2->addChild(menu1, 0);
	
	//������
	auto ad = MenuItemImage::create(
		"ad.png",
		"ad.png",
		CC_CALLBACK_1(SCENE32::onAddItem2, this));
	Menu*menu2 = Menu::create(ad, NULL);
	menu2->setPosition(Point(150, 260));
	bg2->addChild(menu2, 0);

	//��ֽ¨
	auto feizhi = MenuItemImage::create(
		"feizhi.png",
		"feizhi.png",
		CC_CALLBACK_1(SCENE32::onAddItem3, this));
	Menu*menu3= Menu::create(feizhi, NULL);
	menu3->setPosition(Point(400, 180));
	bg2->addChild(menu3, 0);
    
	//���ڼ�ʱ��
	//���ý���������ͼƬ
	Sprite*sprite5= Sprite::create("background.png");

	//����һ��������ť
	pack = MenuItemImage::create("pack_button.png", "pack_button.png", CC_CALLBACK_1(SCENE32::show_pack, this));
	auto menu_3 = Menu::create(pack, NULL);
	this->addChild(menu_3, 5);
	menu_3->setPosition(50, 170);

	//�����˵�����ʾ��ť
	back_to_menu = MenuItemImage::create("back_menu.png", "back_menu.png", CC_CALLBACK_1(SCENE32::to_menu, this));
	tip = MenuItemImage::create("tip.png", "tip.png", CC_CALLBACK_1(SCENE32::show_tip, this));
	auto menu_1 = Menu::create(tip, back_to_menu, NULL);
	this->addChild(menu_1, 5);
	menu_1->alignItemsVerticallyWithPadding(20);
	menu_1->setPosition(Vec2(50, 100));

	return true;
}

void SCENE32::update(float delta)
{
	this->removeChild(labelTime);
	std::stringstream ss;
	std::string val;
	ss << int(leftTime.getTime() / 60);
	ss >> val;
	labelTime = LabelTTF::create(val, "UWJACK8", 60);
	labelTime->setPosition(Vec2(600, 600));
	this->addChild(labelTime);

	if (leftTime.setTime(1.0f))
		return;
	else
	{
		timeOver();
		return;
	}

}

SCENE32::SCENE32():file(getTheName(), getPassword())
{
	
		isInput = false;
		isPressed = false;
		isJumped = false;
		moveVec = Vec2(0, 0);
		moveVecBack = Vec2(0, 0);

}

void SCENE32::onMenuBackButton(cocos2d::Ref* pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(1.0f, FirstTollgate_1::createScene()));
}

void SCENE32::onMenuGoButton(cocos2d::Ref* pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(1.0f, SCENEF1::scene()));
}

void SCENE32::onAddItem1(cocos2d::Ref* pSender)
{
	sprite2 = CCSprite::create("waimaiT.png");
	this->addChild(sprite2, 1);
	sprite2->setPosition(Vec2(480, 300));
	auto closeButton = MenuItemImage::create("CloseButton.png", "CloseButton.png", CC_CALLBACK_1(SCENE32::close_2, this));
	auto button_2 = Menu::create(closeButton, NULL);
	sprite2->addChild(button_2);
	button_2->setPosition(250, 180);
}


void SCENE32::onAddItem2(cocos2d::Ref* pSender)
{
	sprite3 = CCSprite::create("adT.png");
	this->addChild(sprite3, 1);
	sprite3->setPosition(Vec2(480,300));
	auto closeButton = MenuItemImage::create("CloseButton.png", "CloseButton.png", CC_CALLBACK_1(SCENE32::close_3, this));
	auto button_3 = Menu::create(closeButton, NULL);
	sprite3->addChild(button_3);
	button_3->setPosition(250, 180);
}

void SCENE32::onAddItem3(cocos2d::Ref* pSender)
{
	sprite4 = CCSprite::create("ATMT.png");
	this->addChild(sprite4, 1);
	sprite4->setPosition(Vec2(480, 300));
	auto closeButton = MenuItemImage::create("CloseButton.png", "CloseButton.png", CC_CALLBACK_1(SCENE32::close_4, this));
	auto button_4 = Menu::create(closeButton, NULL);
	sprite4->addChild(button_4);
	button_4->setPosition(250, 180);
}

void SCENE32::onKeyPressed(EventKeyboard::KeyCode keyCode, Event *event)
{
	isPressed = true;

	switch (keyCode)
	{
	case EventKeyboard::KeyCode::KEY_ENTER:
	{
		if (isInput)
		{
			isInput = false;
			auto ok = MenuItemImage::create(
				"ok.png",
				"ok.png",
				CC_CALLBACK_1(SCENE32::OkButton, this));
			menu_ok = Menu::create(ok, NULL);
			menu_ok->setPosition(Vec2(480, 120));
			addChild(menu_ok);
			break;
		}
	}
	case EventKeyboard::KeyCode::KEY_0:
	{
		if (isInput)
			num += "0";
		break;
	}
	case EventKeyboard::KeyCode::KEY_1:
	{
		if (isInput)
			num += "1";
		break;
	}
	case EventKeyboard::KeyCode::KEY_2:
	{
		if (isInput)
			num += "2";
		break;
	}
	case EventKeyboard::KeyCode::KEY_3:
	{
		if (isInput)
			num += "3";
		break;
	}
	case EventKeyboard::KeyCode::KEY_4:
	{
		if (isInput)
			num += "4";
		break;
	}
	case EventKeyboard::KeyCode::KEY_5:
	{
		if (isInput)
			num += "5";
		break;
	}
	case EventKeyboard::KeyCode::KEY_6:
	{
		if (isInput)
			num += "6";
		break;
	}
	case EventKeyboard::KeyCode::KEY_7:
	{
		if (isInput)
			num += "7";
		break;
	}
	case EventKeyboard::KeyCode::KEY_8:
	{
		if (isInput)
			num += "8";
		break;
	}
	case EventKeyboard::KeyCode::KEY_9:
	{
		if (isInput)
			num += "9";
		break;
	}

	case EventKeyboard::KeyCode::KEY_A:
	case EventKeyboard::KeyCode::KEY_CAPITAL_A:
	case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
	{
			if (sprite1->getPositionX() > 60)
			{
				moveVec = Vec2(-30, 0);
				break;
			}
			if (bg2->getPositionX() < 1000)
				moveVecBack = Vec2(30, 0);
		}
	break;
	case EventKeyboard::KeyCode::KEY_D:
	case EventKeyboard::KeyCode::KEY_CAPITAL_D:
	case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
	{
			if (sprite1->getPositionX() < 900)
			{
				moveVec = Vec2(30, 0);
				break;
			}
			int t = bg2->getPositionX();
			if (bg2->getPositionX() > -100)
				moveVecBack = Vec2(-30, 0);
		}
	
	break;
	case EventKeyboard::KeyCode::KEY_W:
	case EventKeyboard::KeyCode::KEY_CAPITAL_W:
	case EventKeyboard::KeyCode::KEY_UP_ARROW:

			if (!isJumped&&sprite1->getPositionY() < 300)
			{
				int h = sprite1->getPositionY();

				jumpVec = 50.0;
				isJumped = true;
				auto jump = JumpBy::create(1.0f, Vec2(0, 0), jumpVec, 1);
				auto callFunc = CallFunc::create([=]() {
					isJumped = false;
				});
				sprite1->runAction(Sequence::create(jump, callFunc, NULL));
			
			break;

		}
	default:
	{		
		if (isInput)
			num += "*";//���������ʱ
		break;
	}
	}
	sprite1->runAction(MoveBy::create(0.2, moveVec));
	bg2->runAction(MoveBy::create(0.2, moveVecBack));
	return;
}

void SCENE32::onKeyReleased(EventKeyboard::KeyCode keyCode, Event *event) 
{
	isPressed = false;
	moveVec = Vec2(0, 0);
	moveVecBack = Vec2(0, 0);
	jumpVec = 0.0;
}
// ���û������������ʱ�Ļص�����
bool SCENE32::onTextFieldAttachWithIME(TextFieldTTF *pSender)
{
	return false;
	//return true:������
}
//���û��ر��������ʱ�Ļص�����
bool SCENE32::onTextFieldDetachWithIME(TextFieldTTF *pSender)
{
	return false;
	//return true:���ر�
}
//���û���������ʱ�Ļص�����
bool SCENE32::onTextFieldInsertText(TextFieldTTF *pSender, const char *text, int nLen)
{
	return false;
	//return true:����������ַ�
}
//���û�ɾ������ʱ�Ļص�����
bool SCENE32::onTextFieldDeleteBackward(TextFieldTTF *pSender, const char *delText, int nLen)
{
	return false;
	//return true:��ɾ��
}
//���ֻ��豸�ϻ��������̣������Ϻ����޷�ʵ�֡���
bool SCENE32::TouchBegan(Touch* touch, Event* ev)
{
	//�����ж��Ƿ�����˿ؼ�
	bool isClicked = Password->boundingBox().containsPoint(touch->getLocation());
	//��������˿ؼ�
	if (isClicked)
	{
		//����������
		Password->attachWithIME();
	}
	//��ʾ���ܴ�����Ϣ
	return true;
}

void SCENE32::onMenuButton(cocos2d::Ref* pSender)
{

	ATM= Sprite::create("ATMscene.png");
	ATM->setPosition(Vec2(450, 300));
	this->addChild(ATM);
	WinSize = Director::getInstance()->getVisibleSize();
	isInput = true;
	stringstream ss;
	ss << tryTime;
	 string s1 = ss.str();
	string word = "Input Account..." +s1+"time(s) left";
	text = CCTextFieldTTF::textFieldWithPlaceHolder(
		word, "UWJACK8", 20);
	text->setColor(ccColor3B(255, 255, 255));
	text->setPosition(ccp(WinSize.width / 2, WinSize.height / 2 + 40));
	this->addChild(text);
	num = "";
	text->attachWithIME();


}

void SCENE32::OkButton(Ref* pSpender)
{
	tryTime -= 1;
	/////////////����//////////////////
	if (num == "970113")
	{
		SimpleAudioEngine::getInstance()->stopBackgroundMusic("Xtruist.mp3");

		File file(getTheName(), getPassword());
		file.thirdSceneSuccess();
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SCENE33::scene()));
	}
	if(tryTime<=0)
	{
		auto timecount = CallbackTimeCounter::create();
		this->addChild(timecount);
			Size size = Director::getInstance()->getVisibleSize();
			LabelTTF* tip = LabelTTF::create("You are wrong.\n ", "Arial", 60);
			tip->setPosition(size.width / 2, size.height / 2);
			this->addChild(tip);
			auto try_againScene = Sprite::create("try_againScene.png");
			try_againScene->setPosition(Vec2(470, 320));
			addChild(try_againScene,100);

			MenuItemImage* tryagain = MenuItemImage::create("tryAgain.png", "tryAgain.png", CC_CALLBACK_1(SCENE32::try_again, this));
			MenuItemImage* back = MenuItemImage::create("menu.png", "menu.png", CC_CALLBACK_1(SCENE32::to_menu, this));
			auto menu_2 = Menu::create(tryagain, back, NULL);
			this->addChild(menu_2);
			menu_2->alignItemsVerticallyWithPadding(10);
	}
	else
	{
		removeChild(ATM);
		removeChild(text);
		removeChild(menu_ok);
		auto timecount = CallbackTimeCounter::create();
		this->addChild(timecount);
			Size size = Director::getInstance()->getVisibleSize();
			LabelTTF* tip = LabelTTF::create("Your input is wrong.\n ", "UWJACK8", 40);
			tip->setPosition(size.width / 2, size.height / 2);
			this->addChild(tip);
			timecount->start(2.0f, [=]()
			{
				this->removeChild(tip);
			});

	}
}

void SCENE32::try_again(Ref * pSender)
{
	File file(getTheName(), getPassword());
	leftTime.setTime(-7200 + leftTime.getTime());
	file.looseHeart();
	if (file.checkHeart() > 1)
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SCENE32::scene()));
	}
	else
	{
		file.clearData();
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, MenuScene::createScene()));
	}
}

void SCENE32::show_pack(Ref * pSender)
{
	Size size = Director::getInstance()->getVisibleSize();
	backpack = Sprite::create("backpack.png");
	this->addChild(backpack);
	backpack->setPosition(size.width / 2, size.height / 2);
	auto pack_menu = Menu::create();
	backpack->addChild(pack_menu);
	pack_menu->setPosition(size.width / 2, size.height / 2);
	//��������
	Value de = Value("\n");
	Value d_1 = Value("IDcard: Father ");
	Value d_2 = Value("Life Number: "); Value v_2 = Value(file.checkHeart());
	Value d_3 = Value("Money: "); Value v_3 = Value(file.getMoney());
	Value d_4 = Value("Telescope: "); Value v_4 = Value(file.checkTelescope());
	Value d_5 = Value("Ticket: "); Value v_5 = Value(file.checkTicket());
	Value d_6 = Value("Umbrella: "); Value v_6 = Value(file.checkUmbrella());
	Value d_7 = Value("Newspaper: "); Value v_7 = Value(file.checkNewspaper());
	string  pack_content = d_1.asString() + de.asString() + d_2.asString() + v_2.asString() + de.asString() + d_3.asString() + v_3.asString() + de.asString() + d_4.asString() + v_4.asString() + de.asString() + d_5.asString() + v_5.asString() + de.asString() + d_6.asString() + v_6.asString() + de.asString() + d_7.asString() + v_7.asString() + de.asString();
	auto _pack_content = CCLabelTTF::create(pack_content, "UWJACK8", 40);
	backpack->addChild(_pack_content, 5);
	_pack_content->setPosition(350, 200);

	auto back_scene = MenuItemImage::create("back_scene.png", "back_scene.png", CC_CALLBACK_1(SCENE32::hide_pack, this));
	auto back_scene_button = Menu::create(back_scene, NULL);
	backpack->addChild(back_scene_button);
	back_scene_button->setPosition(400, 30);
}

void SCENE32::hide_pack(Ref * pSender)
{
	this->removeChild(backpack);
}


void SCENE32::show_tip(Ref* pSender)
{
	if (is_look_tip)
	{
		return;
	}
	Size size = Director::getInstance()->getVisibleSize();
	this->is_look_tip = true;
	auto tip = Sprite::create("tiptext_3.png");
	this->addChild(tip);
	tip->setPosition(size.width / 2, size.height - 100);
	CallbackTimeCounter* _tip = CallbackTimeCounter::create();
	this->addChild(_tip);
	_tip->start(5.0f, [=]()
	{
		this->removeChild(tip);
	});
}

void SCENE32::to_menu(Ref* pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(1.0f, MenuScene::createScene()));
}

void SCENE32::timeOver()
{
	File file(getTheName(), getPassword());

	Size size = Director::getInstance()->getVisibleSize();
	auto die_picture = Sprite::create("die_picture.png");
	this->addChild(die_picture, 200);
	die_picture->setPosition(Vec2(470, 320));


	MenuItemImage* tryagain = MenuItemImage::create("tryAgain.png", "tryAgain.png", CC_CALLBACK_1(SCENE32::try_again, this));
	MenuItemImage* back = MenuItemImage::create("menu.png", "menu.png", CC_CALLBACK_1(SCENE32::to_menu, this));
	auto menu_2 = Menu::create(tryagain, back, NULL);
	die_picture->addChild(menu_2, 290);
	menu_2->setPosition(Vec2(470, 170));
	menu_2->alignItemsVerticallyWithPadding(10);

}

string SCENE32::getTheName()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	tempfile >> temp;
	tempfile.close();

	return temp;
}

string SCENE32::getPassword()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp1;
	string temp;
	tempfile >> temp1;
	tempfile >> temp;
	tempfile.close();
	return temp;
}

void SCENE32::close_2(Ref * pSender)
{
	this->removeChild(sprite2);
}

void SCENE32::close_3(Ref * pSender)
{
	this->removeChild(sprite3);

}

void SCENE32::close_4(Ref * pSender)
{
	this->removeChild(sprite4);

}
