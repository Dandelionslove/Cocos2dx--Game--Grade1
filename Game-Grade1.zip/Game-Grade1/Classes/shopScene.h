#ifndef __shopScene_H__
#define __shopScene_H__
#include"cocos2d.h"
#include"CallbackTimeCounter.h"
#include "Calculagraph.h"
#include<map>
using namespace std;
using namespace cocos2d;

class shopScene :public Layer
{
public:
	static Scene* createScene();
	virtual bool init();
	void buyTelescope(Ref*pSender);
	void buyUmbrella(Ref*pSender);
	void returnshopScene(Ref* pSender);
	void okBuyTelescope(Ref * pSender);
	void okBuyUmbrella(Ref * pSender);
	void returnSecondScene(Ref * pSender);
	void show_pack(Ref*pSender);
	void hide_pack(Ref* pSender);
	string getTheName();
	string getPassword();

	void update(float delta)override;

	CREATE_FUNC(shopScene);
protected:
	Menu* menu;
	Calculagraph leftTime;
	Sprite* man;

	Calculagraph shoptime;
	LabelTTF*  shoplabeltime;
	MenuItemImage *pack;//������ť
	Sprite* backpack;//��������

};

#endif // !__shopScene_H__
