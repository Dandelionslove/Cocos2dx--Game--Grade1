#include"scenefinal1.h"
#include"scenefinal2.h"
#include<iostream>
#include "CallbackTimeCounter.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"SimpleAudioEngine.h"
#include"CallbackTimeCounter.h"
#include"MenuScene.h"
USING_NS_CC;
using namespace cocostudio::timeline;
using namespace CocosDenshion;

Scene*SCENEF1::scene()
{
	Scene*scene = Scene::create();
	SCENEF1*layer = SCENEF1::create();
	scene->addChild(layer);
	return scene;
}
bool SCENEF1::init()
{
	if (!Layer::init())
	{
		return false;
	}

	Size size = Director::sharedDirector()->getWinSize();
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Point origin = Director::getInstance()->getVisibleOrigin();

	float width = size.width;
	float height = size.height;
	Sprite*bg3 = Sprite::create("success.png");
	bg3->setPosition(ccp(size.width / 2, size.height / 2));
	float spx = bg3->getTextureRect().getMaxX();
	float spy = bg3->getTextureRect().getMaxY();
	bg3->setScaleX(width / spx); 
	bg3->setScaleY(height / spy);
	this->addChild(bg3);

	//����������������ӵ
	father = Sprite::create("father.png");
	son = Sprite::create("son.png");
	this->addChild(father, 5);
	this->addChild(son,5);
	father->setPosition(0, 230);
	son->setPosition(size.width, 180);
	auto move_1 = MoveTo::create(4.0f, Point(size.width / 2 - 10, 230));
	auto move_2 = MoveTo::create(4.0f, Point(size.width / 2 + 10, 180));
	father->runAction(move_1);
	son->runAction(move_2);

	SimpleAudioEngine::getInstance()->preloadBackgroundMusic("meetloop.mp3");
	//������ʱ��,�������Label��������Ϸ�İ�ť
	CallbackTimeCounter* cbTimeCounter = CallbackTimeCounter::create();
	this->addChild(cbTimeCounter);
	cbTimeCounter->start(4.5f, [=]() 
	{
		auto words_1 = CCLabelTTF::create("Because of your efforts,\nthe father has found his son!\nTHANK YOU!!!!!", "UWJACK8", 40);
		words_1->setColor(Color3B(0, 0, 0));
		this->addChild(words_1,9);
		words_1->setPosition(size.width / 2, 300);
		auto move = MoveTo::create(7.0f, Point(size.width / 2, 800));
		words_1->runAction(move);
		auto show_button = CallbackTimeCounter::create();
		this->addChild(show_button, 9);
		show_button->start(2.0f, [=]() 
		{
			SimpleAudioEngine::getInstance()->playBackgroundMusic("meetloop.mp3");
			auto words_2 = CCLabelTTF::create("However,the real truth is sad......", "UWJACK8", 30);
			words_2->setColor(Color3B(0, 0, 0));
			this->addChild(words_2, 9);
			words_2->setPosition(size.width / 2, 100);
			auto up_1 = MoveTo::create(6.0f, Point(size.width / 2, size.height / 2+100));
			words_2->runAction(up_1);
			auto to_truth_scene = CallbackTimeCounter::create();
			this->addChild(to_truth_scene);
			to_truth_scene->start(6.7f,[=]()
			{
				Director::getInstance()->replaceScene(TransitionCrossFade::create(1.0f, SCENEF2::scene()));
			});
		});
	});
	return true;
}


void SCENEF1::to_menu(Ref * pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(1.0f,MenuScene::createScene()));
}
