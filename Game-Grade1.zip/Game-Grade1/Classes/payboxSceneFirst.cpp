#include"payboxSceneFirst.h"
#include"SimpleAudioEngine.h"
#include "File.h"
#include"FirstTollgate_3.h"
#include"cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include <fstream>

USING_NS_CC;
using namespace CocosDenshion;
using namespace std;

Scene* payboxSceneFirst::createScene()
{
	auto scene = Scene::create();
	auto layer = payboxSceneFirst::create();
	scene->addChild(layer);
	return scene;
}

bool payboxSceneFirst::init()
{
	if (!Layer::init())
	{
		return false;
	}
	//����ͼƬ
	auto scene = Sprite::create("scene_1.jpg");
	Size size = Director::getInstance()->getVisibleSize();
	scene->setPosition(Vec2(size.width / 2, size.height / 2));
	scene->setScaleX(960 / 648);
	scene->setScaleY(640 / 432);
	this->addChild(scene, 0);

	this->scheduleUpdate();


	//��̨
	auto guitai = Sprite::create("guitai.png");
	guitai->setPosition(Vec2(410, 70));
	addChild(guitai);

	//������Ա(change picture)
	auto personnel = MenuItemImage::create(
		"shopper.png",
		"shopper.png",
		CC_CALLBACK_1(payboxSceneFirst::buyTicket, this));
	auto menu_3 = Menu::create(personnel, NULL);
	menu_3->setPosition(Vec2(800, 160));
	this->addChild(menu_3);

	//����������
	auto back = MenuItemImage::create(
		"returnPaybox.png",
		"returnPaybox.png",
		CC_CALLBACK_1(payboxSceneFirst::toSecondScene, this));
	auto menu_8 = Menu::create(back, NULL);
	menu_8->setPosition(Vec2(100, 120));
	this->addChild(menu_8);

	return true;
}

void payboxSceneFirst::buyTicket(Ref * pSender)
{
	//�Ի���
	auto message = Sprite::create("message.png");
	message->setPosition(Vec2(800, 500));
	addChild(message);

	//ȷ�Ϲ���
	auto ok = MenuItemImage::create(
		"ok.png",
		"ok.png",
		CC_CALLBACK_1(payboxSceneFirst::okBuyTicket, this));
	auto menu_5 = Menu::create(ok, NULL);
	menu_5->setPosition(Vec2(750, 120));
	this->addChild(menu_5);

	//����
	auto returnPaybox = MenuItemImage::create(
		"returnPaybox.png",
		"returnPaybox.png",
		CC_CALLBACK_1(payboxSceneFirst::toPopScene, this));
	auto menu_6 = Menu::create(returnPaybox, NULL);
	menu_6->setPosition(Vec2(500, 120));
	this->addChild(menu_6);

}

void payboxSceneFirst::okBuyTicket(Ref * pSender)
{
	File file(getTheName(), getPassword());
	auto timecount = CallbackTimeCounter::create();
	this->addChild(timecount);

	if (file.checkTicket())
	{
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("You had got the ticket.\n ", "UWJACK8", 40);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);

		timecount->start(2.0f, [=]() 
		{
			this->removeChild(tip);
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, payboxSceneFirst::createScene()));
		});

	}

	int num = 1000;
	if (!(file.checkTicket())&&file.getMoney() >= num)
	{
		file.moneyDecrease(num);
		file.buyTicket();
	Size size = Director::getInstance()->getVisibleSize();
	LabelTTF* tip = LabelTTF::create("You get the ticket.\n ", "UWJACK8", 40);
	tip->setPosition(size.width / 2, size.height / 2);
	this->addChild(tip);
	timecount->start(3.0f, [=]()
	{
		this->removeChild(tip);
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, payboxSceneFirst::createScene()));
	});
	}

	if (!(file.checkTicket()) && file.getMoney() < num)
	{
		Size size = Director::getInstance()->getVisibleSize();
		LabelTTF* tip = LabelTTF::create("You do not have enough\nmoney to but it.\n ", "UWJACK8", 40);
		tip->setPosition(size.width / 2, size.height / 2);
		this->addChild(tip);
		timecount->start(3.0f, [=]()
		{
			this->removeChild(tip);
			Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, payboxSceneFirst::createScene()));
		});
	}

}

void payboxSceneFirst::toSecondScene(Ref * pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, FirstTollgate_3::createScene()));

}

void payboxSceneFirst::update(float delta)
{
	this->removeChild(paylabeltime);
	std::stringstream ss;
	std::string val;
	ss << int(leftTime.getTime() / 60);
	ss >> val;
	paylabeltime = LabelTTF::create(val, "UWJACK8", 60);
	paylabeltime->setPosition(Vec2(600, 600));
	this->addChild(paylabeltime);

	if (leftTime.setTime(1.0f))
		return;
	else
	{
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, FirstTollgate_3::createScene()));
	}

}

void payboxSceneFirst::toPopScene(Ref * pSender)
{
	Director::getInstance()->popScene();
}

string payboxSceneFirst::getTheName()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp;
	tempfile >> temp;
	tempfile.close();

	return temp;
}

string payboxSceneFirst::getPassword()
{
	ifstream tempfile;
	tempfile.open("tempfile.txt");
	if (!tempfile)
	{
		log("could not be opened\n");
		exit(EXIT_FAILURE);
	}
	string temp1;
	string temp;
	tempfile >> temp1;
	tempfile >> temp;
	tempfile.close();
	return temp;
}
