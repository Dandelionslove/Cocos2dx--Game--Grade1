#ifndef __funicularScene_H__
#define __funicularScene_H__
#include"cocos2d.h"
#include<map>
#include "Calculagraph.h"
#include"cocos2d.h"
using namespace cocos2d;
USING_NS_CC;
using namespace std;
class  funicularScene :public Layer
{
public:
	static Scene* createScene();
	virtual bool init();
	void update(float delta)override;
	void down(Ref* pSender);
	string getTheName();
	string getPassword();
	CREATE_FUNC(funicularScene);
protected:
	Menu* menu;
	Calculagraph funiculartime;
	LabelTTF*   funicularlabeltime;
	Calculagraph leftTime;

};



#endif