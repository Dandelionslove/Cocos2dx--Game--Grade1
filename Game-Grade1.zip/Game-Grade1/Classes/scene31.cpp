#include"scene31.h"
#include"scene32.h"
#include<iostream>
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
USING_NS_CC;
using namespace CocosDenshion;
using namespace cocostudio::timeline;

Scene*SCENE31::createScene()
{
	Scene*scene = Scene::create();
	SCENE31*layer = SCENE31::create();
	scene->addChild(layer);
	return scene;
}
SCENE31::SCENE31():is_ring(false)
{
}
SCENE31::~SCENE31()
{
}
bool SCENE31::init()
{
	if (!Layer::init())
	{
		return false;
	}
	Size size = Director::sharedDirector()->getWinSize();
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Point origin = Director::getInstance()->getVisibleOrigin();

	float width = size.width;
	float height = size.height;
	auto bg1 = Sprite::create("scene_1.jpg");
	bg1->setPosition(ccp(size.width / 2, size.height / 2));
	float spx = bg1->getTextureRect().getMaxX();
	float spy = bg1->getTextureRect().getMaxY();
	bg1->setScaleX(width / spx); //���þ���������ű���
	bg1->setScaleY(height / spy);
	this->addChild(bg1);

	//���������ĵ绰ͼƬ
	auto item1 = MenuItemImage::create(
		"phone.png",
		"phone.png",
		CC_CALLBACK_1(SCENE31::onMenuItem, this));
	item1->setAnchorPoint(CCPointMake(1, 0));
	Menu*menu1 = Menu::create(item1, NULL);
	menu1->setPosition(Point(size.width+20,20));
	this->addChild(menu1);
	SimpleAudioEngine::sharedEngine()->preloadEffect("threeone.mp3");//��ǰ������Ч
	
	
	return true;
}
void SCENE31::onMenuItem(cocos2d::Ref* pSender)
{
	//�绰ֻ�ܰ���һ��
	if (is_ring)
	{
		return;
	}
	is_ring = true;
	SimpleAudioEngine::sharedEngine()->playEffect("threeone.mp3");
	SimpleAudioEngine::sharedEngine()->setEffectsVolume(1.0);//��������0.0~1.0

	 //������ʱ�� 
	CallbackTimeCounter* cbTimeCounter = CallbackTimeCounter::create();
	this->addChild(cbTimeCounter);
	cbTimeCounter->start(0.9f, [=]() {
		auto button = MenuItemImage::create(
			"start.png",
			"start.png",
			CC_CALLBACK_1(SCENE31::onMenuButton, this));
		Menu*menu1 = Menu::create(button, NULL);
		this->addChild(menu1,5);
		Size size = Director::getInstance()->getVisibleSize();
		menu1->setPosition(size.width / 2, 100);
		
		auto content = CCLabelTTF::create("I have told you not to turn to the police, \nbut you still trust those stupid cops! \nLook at your pity\'s sake, \nI\'ll give you another chance, \nwearing red clothes to West cave department store, \nusing the ATM machine near to transfer 100 million , \nthe account I will tell you later, \nremember, \nbe sure you will wear red clothes.\n", "UWJACK8", 20);
		this->addChild(content,4);
		content->setPosition(size.width / 2, size.height / 2);
	});
}
void SCENE31::onMenuButton(cocos2d::Ref* pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(1.0f, SCENE32::scene()));
	SimpleAudioEngine::getInstance()->stopAllEffects();//ת��������ʱ��ֹͣ���ŵ绰��
}