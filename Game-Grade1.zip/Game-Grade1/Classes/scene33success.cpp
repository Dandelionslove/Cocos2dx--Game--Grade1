#include"scene33success.h"
#include<iostream>
#include"scenefinal1.h"
#include "cocostudio/CocoStudio.h"
#include"CallbackTimeCounter.h"
#include "ui/CocosGUI.h"
#include"SimpleAudioEngine.h"
USING_NS_CC;
using namespace cocostudio::timeline;
using namespace CocosDenshion;

Scene*SCENE33::scene()
{
	Scene*scene = Scene::create();
	SCENE33*layer = SCENE33::create();
	scene->addChild(layer);
	return scene;
}
bool SCENE33::init()
{
	if (!Layer::init())
	{
		return false;
	}

	SimpleAudioEngine::getInstance()->playBackgroundMusic("theater.mp3");
	Size size = Director::sharedDirector()->getWinSize();
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Point origin = Director::getInstance()->getVisibleOrigin();

	float width = size.width;
	float height = size.height;
	CCSprite*bg3 = CCSprite::create("menuBG.png");
	bg3->setPosition(ccp(size.width / 2, size.height / 2));
	float spx = bg3->getTextureRect().getMaxX();
	float spy = bg3->getTextureRect().getMaxY();
	bg3->setScaleX(width / spx);
	bg3->setScaleY(height / spy);
	this->addChild(bg3);

	//�����˻���Ϣ��ͼƬ
	account = Sprite::create("account.png");
	this->addChild(account);
	account->setPosition(size.width / 2, size.height / 2);
	auto blink = Blink::create(1.0f, 1);
	auto big = ScaleBy::create(4.0f, 3);
	account->runAction(Spawn::create(blink,big,NULL));
	
	auto show_success = CallbackTimeCounter::create();
	this->addChild(show_success);
	show_success->start(2.0f, [=]() 
	{
		auto words = CCLabelTTF::create("Congratuations!The final clue has been found!", "Arial", 30);
		this->addChild(words);
		words->setPosition(size.width/2, 400);
		words->setColor(Color3B(0, 0, 0));
		auto move = MoveTo::create(7.0f, Point(size.width / 2,800));
		words->runAction(move);
	});

	auto to_final_scene = CallbackTimeCounter::create();
	this->addChild(to_final_scene);
	to_final_scene->start(7.5f, [=]() 
	{
		Director::getInstance()->replaceScene(TransitionFadeUp::create(0.5f,SCENEF1::scene()));
	});
	return true;
}
