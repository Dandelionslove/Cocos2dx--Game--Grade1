#include"SecondTollgate_1.h"
#include"SimpleAudioEngine.h"
#include"SecondTollgate_2.h"

USING_NS_CC;
using namespace CocosDenshion;
using namespace std;

Scene* SecondTollgate_1::createScene()
{
	auto scene = Scene::create();
	auto layer = SecondTollgate_1::create();
	scene->addChild(layer);
	return scene;
}

bool SecondTollgate_1::init()
{
	if (!Layer::init())
	{
		return false;
	}
	//����ͼƬ
	auto scene = Sprite::create("scene_1.jpg");
	Size size = Director::getInstance()->getVisibleSize();
	scene->setPosition(Vec2(size.width / 2, size.height / 2));
	scene->setScaleX(960 / 648);
	scene->setScaleY(640 / 432);
	this->addChild(scene,0);

	//�绰��
	SimpleAudioEngine::getInstance()->playEffect("phone.mp3", true);

	//���ڽ���ʱ�����ٴε��
	auto phone = MenuItemImage::create("telephone.png", "telephone.png", CC_CALLBACK_1(SecondTollgate_1::phoneRing, this));
	
	//���õ绰λ��
	menu = Menu::create(phone, NULL);
	menu->setPosition(Vec2(600, 100));
	this->addChild(menu, 1);
	
	return true;
}

void SecondTollgate_1::phoneRing(Ref* pSender)
{
	if (isRing)
	{
		return;
	}
	isRing = true;
	SimpleAudioEngine::getInstance()->stopAllEffects();
	SimpleAudioEngine::getInstance()->playBackgroundMusic("Second_1.wav");

	//�绰����
	string content = "Do you really want your son alive?\nDo not make the same mistake again, \nonce I get the money, \nI will give him back.  \nRemember, \nI am watching you, \nincluding your every movement. \nNow I come to confirm that no police follow us. \nDon��t worry your son is well, \nyou have no choice but to trust me, \nah, the scenery is pretty good, \nyou should enjoy. \nNow stop your car, \nleaving the money in the car \nand pull on the cable car, \nShangyu is waiting for you \nat the top of the hill .";
	auto _content = LabelTTF::create(content, "Arial", 20);

	//�绰�����ı�λ��
	Size size=Director::getInstance()->getVisibleSize();
	_content->setPosition(size.width/2, size.height/2);
	this->addChild(_content,3);
	
	//���ص绰
	this->menu->setOpacity(0);

	//������һ�������İ�ť
	auto next = MenuItemImage::create("forward.png","forward.png",CC_CALLBACK_1(SecondTollgate_1::next_scene,this));
	next->setScale(2.5f);
	auto _menu = Menu::create(next, NULL);
	_menu->setPosition(Vec2(600,200));
	_menu->setScale(0.5);
	this->addChild(_menu, 5);


	auto callFunc = CallFunc::create([&]() {
		isRing = false;
	});
}

void SecondTollgate_1::next_scene(Ref* pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, SecondTollgate_2::createScene()));
	SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
}

