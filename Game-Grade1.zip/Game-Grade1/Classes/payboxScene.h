#ifndef __payboxScene_H__
#define __payboxScene_H__

#include"cocos2d.h"
#include<map>

#include"CallbackTimeCounter.h"
#include "Calculagraph.h"
using namespace cocos2d;
USING_NS_CC;
using namespace std;

class  payboxScene :public Layer
{
public:
	static Scene* createScene();
	bool init();
	void buyTicket(Ref*pSender);
	void okBuyTicket(Ref * pSender);
	void toSecondScene(Ref * pSender);
	void update(float delta)override;
	void toPopScene(Ref * pSender);
	string getTheName();
	string getPassword();

	CREATE_FUNC(payboxScene);
protected:
	Menu* menu;
	CCProgressTimer* progressTimer;
	Calculagraph leftTime;
	Sprite* man;
	Calculagraph paytime;
	LabelTTF*  paylabeltime;
};
#endif
