#ifndef __THREE_SCENE31_H__
#define __THREE_SCENE31_H__
#include<iostream>
#include "SimpleAudioEngine.h"
#include "cocos2d.h"
#include"TimeCounter.h"
#include"CallbackTimeCounter.h"
using namespace cocos2d;

class SCENE31 :public cocos2d::Layer {
public:
	SCENE31();
	~SCENE31();
	virtual bool init();
	static  cocos2d::Scene* createScene();
	void onMenuItem(cocos2d::Ref* pSender);
	void onMenuButton(cocos2d::Ref* pSender);
	CREATE_FUNC(SCENE31);
protected:
	bool is_ring;
};
#endif