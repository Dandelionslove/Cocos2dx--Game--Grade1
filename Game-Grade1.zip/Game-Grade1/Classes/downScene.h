#ifndef __downScene_H__
#define __downScene_H__
#include"cocos2d.h"
#include<map>
#include "Calculagraph.h"
#include"cocos2d.h"
using namespace cocos2d;
USING_NS_CC;
using namespace std;
class  downScene :public Layer
{
public:
	static Scene* createScene();
	virtual bool init();
	void update(float delta)override;
	void toSecondScene(Ref* pSender);
	CREATE_FUNC(downScene);
protected:
	Menu* menu;
	Calculagraph downtime;
	LabelTTF*   downlabeltime;
	Calculagraph leftTime;

};



#endif