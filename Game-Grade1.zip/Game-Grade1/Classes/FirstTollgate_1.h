#pragma once

#ifndef _FirstTollgate_1_H_
#define _FirstTollgate_1_H_

#include"cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"TimeCounter.h"
#include"CallbackTimeCounter.h"
#include"FirstTollgate_2.h"


using namespace cocos2d;

class FirstTollgate_1 :public Layer
{
public:
	FirstTollgate_1();
	~FirstTollgate_1();
	static Scene* createScene();
	virtual bool init();
	void PhoneRing(Ref*pSender);
	void go_next(Ref* pSender);
	CREATE_FUNC(FirstTollgate_1);
protected:
	MenuItemImage *phone;
	CallbackTimeCounter* show_content;
	bool is_phone_ring;
};
#endif
