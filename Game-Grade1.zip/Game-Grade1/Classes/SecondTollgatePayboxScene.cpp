#include "SecondTollgatePayboxScene.h"

bool SecondTollgatePayboxScene::init()
{
	if (!Layer::init())
	{
		return false;
	}
	//����ͼƬ
	auto scene = Sprite::create("scene_1.jpg");
	Size size = Director::getInstance()->getVisibleSize();
	scene->setPosition(Vec2(size.width / 2, size.height / 2));
	scene->setScaleX(960 / 648);
	scene->setScaleY(640 / 432);
	this->addChild(scene, 0);

	//������Ա
	auto  personnel = MenuItemImage::create("man.png", "man.png", CC_CALLBACK_1(payboxScene::buyTicket, this));
	menu = Menu::create(personnel, NULL);
	menu->setPosition(Vec2(500, 200));
	this->addChild(menu, 1);

	//��̨
	auto guitai = Sprite::create("guitai.png");
	guitai->setPosition(Vec2(500, 200));
	addChild(guitai);

	//���صڶ��ؿ�������
	auto returnPaybox = MenuItemImage::create(
		"returnPaybox.png",
		"returnPaybox.png",
		CC_CALLBACK_1(payboxScene::toSecondScene, this));
	auto menu_6 = Menu::create(returnPaybox, NULL);
	menu_6->setPosition(Vec2(200, 120));
	this->addChild(menu_6);

	this->scheduleUpdate();


	return true;
}
