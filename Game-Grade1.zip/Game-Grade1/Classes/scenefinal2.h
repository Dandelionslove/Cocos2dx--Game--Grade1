
#ifndef __THREE_SCENEF2_H__
#define __THREE_SCENEF2_H__
#include<string>
#include "cocos2d.h"
#include "TimeCounter.h"
#include "SimpleAudioEngine.h"
using namespace cocos2d;

class SCENEF2 :public cocos2d::Layer {
public:
	virtual bool init();
	static  cocos2d::Scene* scene();
	void Try_again(Ref* pSender);
	void cancelMenuItemCallback(Ref* pSender);
	void rollText(float);
	CREATE_FUNC(SCENEF2);
private:
	TimeCounter* m_timeCounter;
	LabelTTF* text;
};
#endif



