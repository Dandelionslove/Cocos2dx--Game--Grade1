#include"Requirement.h"
#include"SimpleAudioEngine.h"
#include"MenuScene.h"


USING_NS_CC;
using namespace CocosDenshion;
Scene* Requirement::createScene()
{
	auto scene = Scene::create();
	auto layer = Requirement::create();
	scene->addChild(layer);
	return scene;
}

bool Requirement::init()
{
	if (!Layer::init())
	{
		return false;
	}

	auto rootNode = CSLoader::createNode("BeginningScene.csb");
	addChild(rootNode);
	SimpleAudioEngine::getInstance()->playBackgroundMusic("Lightening.mp3", true);

	Size visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();
	auto item = MenuItemImage::create(
		"forward.png",
		"forward.png",
		CC_CALLBACK_1(Requirement::menuCloseCallback,this));
	auto menu = Menu::create(item, NULL);
	menu->setPosition(Vec2(460,90));
	this->addChild(menu,1);

	return true;
}

void Requirement::menuCloseCallback(Ref* pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f, MenuScene::createScene()));
}