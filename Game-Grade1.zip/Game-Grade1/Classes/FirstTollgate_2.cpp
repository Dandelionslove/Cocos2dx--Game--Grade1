#include"FirstTollgate_2.h"
#include"SimpleAudioEngine.h"
#include"FirstTollgate_3.h"


using namespace CocosDenshion;
using namespace ui;
USING_NS_CC;

Scene* FirstTollgate_2::createScene()
{
	auto scene = Scene::create();
	auto layer = FirstTollgate_2::create();
	scene->addChild(layer);
	return scene;
}

bool FirstTollgate_2::init()
{
	if (!Layer::init())
	{
		return false;
	}

	
	size = Director::getInstance()->getVisibleSize();
	auto background = Sprite::create("rainday.png");
	background->setPosition(size.width / 2, size.height / 2);
	background->setScale(1.5, 1.3);
	this->addChild(background);

	auto carwithman = Sprite::create("car.png");
	this->addChild(carwithman);
	carwithman->setPosition(0, 130);
	//��һ����ʱ������ʻ���Ժ
	auto move_1 = MoveTo::create(2.0f, Point(400, 130));
	carwithman->runAction(move_1);
	func_1 = CallbackTimeCounter::create();
	this->addChild(func_1);
	func_1->start(2.5f, [=]()
	{
		carwithman->removeFromParent();
		auto empty_car = Sprite::create("emptycar.png");
		this->addChild(empty_car, 10);
		empty_car->setPosition(400, 130);
		man = Sprite::create("man.png");
		this->addChild(man, 9);
		man->setPosition(450, 130);
		ccBezierConfig route;
		route.controlPoint_1 = Point(500, 130);
		route.controlPoint_2 = Point(470, 150);
		route.endPosition = Point(350, 170);
		BezierTo *walk = BezierTo::create(3.0f, route);
		man->runAction(walk);

	});
	//�ڶ�����ʱ�����������̵����һ�����绰����
	func_2 = CallbackTimeCounter::create();
	this->addChild(func_2);
	func_2->start(7.0f, [=]()
	{
		SimpleAudioEngine::getInstance()->playBackgroundMusic("First_2.wav");
		auto add = CallbackTimeCounter::create();//��ʱ�����绰�����Ժ�������ݺ�ǰ����ť
		this->addChild(add);
		add->start(1.1f, [=]()
		{
			auto content = Sprite::create("phonecontent.png");
			this->addChild(content);
			content->setPosition(400, 450);

			//ǰ����ť
			auto button = MenuItemImage::create("forward.png", "forward.png", CC_CALLBACK_1(FirstTollgate_2::go_next, this));
			auto _button = Menu::create(button, NULL);
			this->addChild(_button);
			_button->setPosition(500, 300);
		});

		auto add_func_1 = CallbackTimeCounter::create();
		this->addChild(add_func_1);
		add_func_1->start(42.0f, [=]()
		{
			SimpleAudioEngine::getInstance()->playBackgroundMusic("meetloop.mp3");
			auto move_2 = MoveTo::create(1.0f, Point(520, 135));
			man->runAction(move_2);
			auto add_func_2 = CallbackTimeCounter::create();
			this->addChild(add_func_2);
			add_func_2->start(2.0f, [=]()
			{
				Director::getInstance()->replaceScene(TransitionCrossFade::create(2.0f, FirstTollgate_3::createScene()));
			});
		});
	});
	return true;
}

void FirstTollgate_2::go_next(Ref* pSender)
{
	Director::getInstance()->replaceScene(TransitionCrossFade::create(0.0f,FirstTollgate_3::createScene()));
}