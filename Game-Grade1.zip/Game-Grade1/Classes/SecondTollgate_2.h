#pragma once
#ifndef _SecondTollgate_2_H
#define _SecondTollgate_2_H
#include"cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"CallbackTimeCounter.h"
#include"Calculagraph.h"
#include "file.h"

using namespace cocos2d;
using namespace std;
using namespace ui;

class SecondTollgate_2 :public Layer
{
public:
	SecondTollgate_2();
	~SecondTollgate_2();
	static Scene* createScene();
	virtual bool init();
	void next_scene(Ref* pSender);
	void paybox_scene(Ref* pSender);
	void useTicketScene(Ref* pSender);
	void try_again(Ref* pSender);
	void to_menu(Ref* pSender);
	void shopScene(Ref* pSender);
	void update(float delta)override;
	void dropInto();
	void timeOver();
	void show_tip(Ref* pSender);
	void show_pack(Ref * pSender);
	void hide_pack(Ref* pSender);
	string getTheName();
	string getPassword();

	void update_of_stone(float time);
	bool is_hitted();
	void update_of_judge_position(float time);
	void show_hitted_pictrue();

	float map() {
		isPressed = false;
		isJumped = false;
		moveVec = Vec2(0, 0);
	}

	CREATE_FUNC(SecondTollgate_2);
protected:
	Menu* menu;
	Sprite* man;
	Size size;
	File file;
	CCProgressTimer* progressTimer;
	MenuItemImage* back_to_menu;
	MenuItemImage* tip;
	Calculagraph leftTime;
	LabelTTF* labelTime;
	MenuItemImage *pack;//������ť
	Sprite* backpack;//��������
private:
	//void addPlayer(TMXTiledMap* map);
	cocos2d::TMXTiledMap *_tileMap;
	cocos2d::TMXLayer *_background;
	bool is_look_tip;
	bool isPressed;
	bool isJumped;
	Vec2 moveVec;
	float jumpVec;

	Sprite* big_stone;
	Sprite* small_stone;
	bool is_big_roll;
	bool is_small_roll;
	Sprite* die_picture;
	MenuItemImage* die_back;//����ͼƬ�Ϸ��ز˵�����İ�ť
	MenuItemImage *die_tryagain;

	void onKeyPressed(EventKeyboard::KeyCode keyCode, Event *event);
	void onKeyReleased(EventKeyboard::KeyCode keycode, Event *event);
};
#endif
