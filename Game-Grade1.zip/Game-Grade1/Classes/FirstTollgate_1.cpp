#include"FirstTollgate_1.h"
#include"SimpleAudioEngine.h"

USING_NS_CC;
using namespace CocosDenshion;
using namespace ui;
using namespace std;

FirstTollgate_1::FirstTollgate_1():is_phone_ring(false)
{

}

FirstTollgate_1::~FirstTollgate_1()
{

}

Scene* FirstTollgate_1::createScene()
{
	auto scene = Scene::create();
	auto layer = FirstTollgate_1::create();
	scene->addChild(layer);
	return scene;
}

bool FirstTollgate_1::init()
{
	if (!Layer::init())
	{
		return false;
	}
	Size size = Director::getInstance()->getVisibleSize();
	auto scene = Sprite::create("scene_1.jpg");
	scene->setAnchorPoint(Vec2(0.5, 0.5));
	scene->setPosition(Vec2(size.width / 2, size.height / 2));
	scene->setScaleX(960 / 648);
	scene->setScaleY(640 / 480);
	this->addChild(scene,1);

	phone = MenuItemImage::create("telephone.png", "telephone.png", CC_CALLBACK_1(FirstTollgate_1::PhoneRing, this));
	auto menu_1 = Menu::create(phone, NULL);
	this->addChild(menu_1,2);
	menu_1->setPosition(600, 100);
	
	if (is_phone_ring)
	{
		phone->setEnabled(false); 
	}
	return true;
}

void FirstTollgate_1::PhoneRing(Ref*pSender)
{
	if (is_phone_ring)
	{
		return;
	}
	this->is_phone_ring = true;//�绰��

	//����˶���
	int num = 4;
	int num2 = 200;
	CCAnimation *animation_1 = CCAnimation::create();
	for (int j = 1; j <= 200; j++)
	{
		for (int i = 1; i <= 4; ++i)
		{
			char pName[30] = { 0 };
			sprintf(pName, "man_%d.png", i);
			animation_1->addSpriteFrameWithFileName(pName);
		}
	}
	animation_1->setDelayPerUnit(1.0f / 10.0f);
	animation_1->setRestoreOriginalFrame(true);
	CCAnimate *action = CCAnimate::create(animation_1);
	CCSprite *sprite = CCSprite::create("man_1.png");
	sprite->setAnchorPoint(Vec2(1.0f, 1.0f));
	sprite->setPosition(Vec2(650, 130));
	this->addChild(sprite, 2);
	/////����˶���������
	SimpleAudioEngine::getInstance()->playEffect("First_1.wav");

	sprite->runAction(CCRepeat::create(action,num));
	//����ǰ����ť
	auto next = MenuItemImage::create("forward.png", "forward.png", CC_CALLBACK_1(FirstTollgate_1::go_next, this));
	auto menu_2 = Menu::create(next, NULL);
	menu_2->setPosition(Vec2(780, 100));
	this->addChild(menu_2,7);

	this->show_content = CallbackTimeCounter::create();
	this->addChild(show_content);
	show_content->start(8.0f, [=]()
	{
		string content_1 = "Hello, \nI like your news, \nShang Yu's father, \nyou're much calmer than I imagined. \nShang Yu and I are together. \nIt seems that you are still acute, \nso get 100 million ready before tomorrow \nand go to the Jidong theater, \nthen you should go to the near store \nleaving the car and bag . \nHaving a telephone installed in your car, \nand pick up the phone before it rings three times, \nremember just three times, \nI'll call back tomorrow. \nI probably don't need to tell you who I am, \nbut if you turn to the police or annoy me, \nthen wait for a corpse.";
		CCLabelTTF* content = CCLabelTTF::create(content_1, "UWJACK8", 20);
		Size size = Director::getInstance()->getVisibleSize();
		content->setPosition(Vec2(size.width*1/3,size.height/2));
		this->addChild(content,7);
	}
	);
}

void FirstTollgate_1::go_next(Ref* pSender)
{
	SimpleAudioEngine::getInstance()->stopAllEffects();
	Director::getInstance()->replaceScene(TransitionCrossFade::create(2.0f,FirstTollgate_2::createScene()));
}


